# Info.p2pu.org  - feedback

*   line spacing for bullet points vs normal text, should be the same

![](https://s3.amazonaws.com/uploads.hipchat.com/1592/42242/uZc9clSKRBVGQ0o/Screen%20Shot%202014-01-28%20at%2011.16.45%20AM.png)

[](https://s3.amazonaws.com/uploads.hipchat.com/1592/42242/uZc9clSKRBVGQ0o/Screen%20Shot%202014-01-28%20at%2011.16.45%20AM.png)https://s3.amazonaws.com/uploads.hipchat.com/1592/42242/uZc9clSKRBVGQ0o/Screen%20Shot%202014-01-28%20at%2011.16.45%20AM.png

*   Search bar sits too tightly at the top. In OSX Chrome

![](https://s3.amazonaws.com/uploads.hipchat.com/1592/42242/uZc9clSKRBVGQ0o/Screen%20Shot%202014-01-28%20at%2011.16.45%20AM.png)

[](https://s3.amazonaws.com/uploads.hipchat.com/1592/42242/uZc9clSKRBVGQ0o/Screen%20Shot%202014-01-28%20at%2011.16.45%20AM.png)https://s3.amazonaws.com/uploads.hipchat.com/1592/42242/uZc9clSKRBVGQ0o/Screen%20Shot%202014-01-28%20at%2011.16.45%20AM.png