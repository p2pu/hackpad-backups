# Community Call 31 October 2013

Attendees:

Project Reports:

*

Agenda

*   <u>Progress (what we've been working on)</u>

    *

*   <u>Priorities (focus next week)</u>

    *

*   <u>Problems (walls we ran into on the way)</u>
*   <u>Process (org stuff)</u>
*   <u>Ideas (on the horizon)</u>

Discussion