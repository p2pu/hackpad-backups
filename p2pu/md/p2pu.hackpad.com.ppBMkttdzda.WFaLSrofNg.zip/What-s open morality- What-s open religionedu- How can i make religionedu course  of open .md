# What's open morality? What's open religionedu? How can i make religionedu course  of open 

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!