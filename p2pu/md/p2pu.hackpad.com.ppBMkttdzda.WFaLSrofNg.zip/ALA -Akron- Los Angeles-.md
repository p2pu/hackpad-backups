# ALA (Akron, Los Angeles) 

**Copyright Course** (Starting March 24, 2014) 

Andrea Novicky (Akron Area)  & Glen Warren (Los Angeles Area)

**FIrst Discussion Questions:**

(1) What is the idea/expression distinction? Why is it important?

[Glen Warren](/ep/profile/qqp8lEdVFqf)

_Is seems that an idea is not protected by copyright, but the expression of the idea is protected._

_What makes it important the idea of the first light bulb is wide open to anyone who can come up with the first expression of a working lightbulb.     _

(2) How would you go about determining whether or not each of the following resources are in the public domain? (What questions would you ask about the work and its creator? What additional information would you need to know?)

*   A book from the library

[Glen Warren](/ep/profile/qqp8lEdVFqf)

_The copyright date, Indivdual or Joint Authors, Corporate Authorship, and  utilize the ALA calulator (_[](http://librarycopyright.net/resources/digitalslider/))http://librarycopyright.net/resources/digitalslider/).  _Look for Creative Commons Licence. _

*   A photo you found on the Internet

_The copyright date, Indivdual or Joint Authors, Corporate Authorship, and  utilize the ALA calulator (_[](http://librarycopyright.net/resources/digitalslider/))[http://librarycopyright.net/resources/digitalslider/](http://librarycopyright.net/resources/digitalslider/)).  _Look for Creative Commons Licence. _

*   A federal court decision

_The court decision is public domain and long as the decision has special limitations.  _