# Community Call - 20 February 2014

[community call starting late today.... Our apologies.  Starting imminently...]

We're hanging out here: 

[](https://plus.google.com/hangouts/_/hoaevent/AP36tYenHCNIUmSr41xFZPtV45tB-2P-uoCVvqz7G7-0pd_S_6aXpA?authuser=1&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYenHCNIUmSr41xFZPtV45tB-2P-uoCVvqz7G7-0pd_S_6aXpA?authuser=1&hl=en

 - join us! 

**Attendees**

*   [Bekka Kahn](/ep/profile/BT4g65BvPRV)
*   [Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)
*   [Dirk Uys](/ep/profile/ppBMkttdzda)
*   [Philipp Schmidt](/ep/profile/Dc7zU8svumi)

**The P2PU Weekly Roundup - see Project Pad**

*   UPDATE: New format for this call: P2PU now doing a 'project call' at 10am EST Thursdays (1hr before this call) to report on work in progress and discuss specific projects

**Discussion**

<s>Is there a hangout associated with this pad? - yup - scroll up.</s>

How to start Hangouts? (Do we have a how-to somewhere, so that anyone can start these calls?)

*   We should try out lower thirds
*   BK will add a How-To hackpad

Hi Michael!

*   We <3 teachers
*   Set up a call to connect teachers

How do we handle expressions of interest in the MechMOOC?

*   start conversation on thepeople and send people to the conversation
*   VMG can set this up (thanks!!)

Badge conversation in SF

*   Conversation has moved to a different level - still interesting questions, but bigger impact
*   Great to see the kernel of an idea, we helped create, has grown up to a large movement
*   Mike: Digital diplomas with curated competencies is the future. Problems are organizational. More useful if you had a universal badge viewer (displayer), with functionality like filtering, privacy/control over sharing.... [anticipates a big 'digital wallet' of badges to be managed?] 

<u>Interesting Reading:</u>

Alex Hillman: Communities and Products [](http://dangerouslyawesome.com/2014/02/what-do-communities-product-businesses-have-in-common/)http://dangerouslyawesome.com/2014/02/what-do-communities-product-businesses-have-in-common/

Instructional Design is not Interface Design: [](http://brianwhitmer.blogspot.com.au/2014/02/instructional-design-is-not-interface.html)http://brianwhitmer.blogspot.com.au/2014/02/instructional-design-is-not-interface.html

6 Insights from the World of Motivational Research

(Thieme and Tim) [](https://iversity.org/blog/mit-meeting-motivation/)https://iversity.org/blog/mit-meeting-motivation/

Your Unguided Tour of #Rhizo14 [](http://davecormier.com/edblog/2014/01/12/your-unguided-tour-of-rhizo14/)http://davecormier.com/edblog/2014/01/12/your-unguided-tour-of-rhizo14/