# Website sprint - July 2014

Issues for website sprint:

*   change discourse name & all other references to it

*   Do we want to change the title of discourse?
*   We've changed it already - from thepeople
*   Is this done? 

*   [Philipp claims] Implement top nav

*   Let's set it's items together (what should be a part of a top navigation, what should be secondary navigation and what should be linked, but it is not necessarily part of top navigation (TOU, Strategy,...). Here is the link to the top navigation as it is set out to be: [Website changes: Proposed universal nav menu (d](/b0IpkN3UgQu#:h=Proposed-universal-nav-menu-(d)
*   Please put all of your feedback as a comment on the menu item that you are commenting and all of your ideas an thoughts below. This top navigation will be on all of our pages (home page, info.p2pu.org, community.p2pu.org,...), so we should aim fr general items 'push' engagement with us, but leave out linking the content which gets outdated fast. Remember we will implement this, but still do some testing, so we can change that a bit trough time.

*   Add top nav to new site mockup
*   Update/consolidate stale content orphaned by top nav

*   CARL upgrade CC 4.0

*   upgrade homepage

*   Repository for all the content and the design made until now [](https://github.com/p2pu/p2pu-website)https://github.com/p2pu/p2pu-website[ ](https://github.com/p2pu/p2pu-websiteis)is here and the changes are visible [](http://p2pu.github.io/p2pu-website/)http://p2pu.github.io/p2pu-website/[ ](http://p2pu.github.io/p2pu-website/here)here.

*   implement track record page / media kit 

*   Make a list of people who should be on the page, update copy, find images

*   BEKKA tag blogposts/community calls

*   There is a serious amount of community calls that need to be transferred from Bekkas channel to p2pu channel
*   At present, youtube doesn't let you transfer videos between channels without downloading them first (which might kill my computer), One way to manage this might be just to make sure that they are tagged VERY well, so they are searchable? ([](https://support.google.com/youtube/answer/2404846?hl=en-GB))https://support.google.com/youtube/answer/2404846?hl=en-GB)

*   review old help content to salvage anything good; drop into new pages on community.p2pu.org?

*   Add P2PU topnav to community.p2pu.org

Ideas/suggestions

*   create a dedicated page for community calls

*   I think this could be a part of our homepage

*   here's our content map from past work: [](https://docs.google.com/a/p2pu.org/spreadsheet/ccc?key=0AiJ5HTWV0kHJdFpmZWN0djB4VnpiWTBfcmZhdnZaOFE&usp=drive_web#gid=0)[https://docs.google.com/a/p2pu.org/spreadsheet/ccc?key=0AiJ5HTWV0kHJdFpmZWN0djB4VnpiWTBfcmZhdnZaOFE&usp=drive_web#gid=0](https://docs.google.com/a/p2pu.org/spreadsheet/ccc?key=0AiJ5HTWV0kHJdFpmZWN0djB4VnpiWTBfcmZhdnZaOFE&usp=drive_web#gid=0)
*   Setup bitcoin donations