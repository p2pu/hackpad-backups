# Dashboard Tech

Functional requirements

*   Gather stats daily or more frequently
*   Store stats in db
*   Display stats
*   Manually record important events