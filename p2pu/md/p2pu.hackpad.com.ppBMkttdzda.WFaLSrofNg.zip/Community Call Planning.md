# Community Call Planning

Suggestion: we no longer call this the community call - it can be many different things (all of them open) 

Some weeks it will be a staff call 

Some weeks it will be an all-hands where things need to be done

Some weeks it will be a planning session for communications calendars/long-term projects/events

Some weeks it will be a brown-bag style seminar with an invited guest

All weeks it will be a quick stand-up to make sure everyone is aware of everything

For the next 4 weeks we have:

Thurs 30th - 

Report back: Govlab update, Mozfest, PWYM

Missing: Philipp (at OGP in London)

Thurs 7 November:

Thurs 14 November

Thurs 21 November

Thurs 28 November

If you want to "book" any of these weeks for a particular session, let me know here. If not, I'm going to allocate them according to who is available when, and 