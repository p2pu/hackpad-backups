# Ioana's Research

- do you have any course-specific data that you could make available to me after the course is over (participation metrics, login counts, and the like?), so I can better explore the patterns of participation?

*   Pageviews, comments, time on site (not reliable)
*   [](http://badges.p2pu.org/en/)http://badges.p2pu.org/en/
*   Login count--very probable
*   [](https://p2pu.org/en/courses/111/copyright-4-educators-aus/)https://p2pu.org/en/courses/111/copyright-4-educators-aus/ 95% completion rate 

- could P2PU perhaps help me with promoting the course on the blog or newsletter?

*   blog post on info.p2pu.org
*   twitter community
*   newsletter
*   arts in education organizations
*   arts in technology organizations--blogs and content aggregators

- do you have any specific suggestions that might help me combat the attrition issue that is characteristic of online courses? Given my goals for this course, it is vital that the students remain engaged from beginning till end, because I am trying to scaffold their creative participation and build community. Moreover, from a practical perspective, what happens in Weeks 5-6 will really answer my research question of whether co-design is possible; if participants drop out before then, I will be unable to address my research question. 

*   pre-course assignment (bump!)
*   Google+ 
*   to divide them into groups: by timezone, interest, level of expertise, randomly? 
*   [](https://github.com/p2pu/mechanicalmooc)https://github.com/p2pu/mechanicalmooc
*