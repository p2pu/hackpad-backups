# community website examples

[extending discussion started in [Website strategy](/FutFPwsNev8) pad]

[](http://publiclab.org)http://[p](http://Public)u[b](http://puPublic)l[i](http://publPublic)c[l](http://publicPublic)a[b](http://publiclaPublic).[o](http://publiclab.Public)r[g](http://publiclab.orPublic) - Public Lab

*   resources and community

[](http://www.3ders.org/index.html)<u>[http://www.3ders.org/index.html](http://www.3ders.org/index.html)</u> - 3D printing

- website and forums

- website: mainly news/links.  Small amount of original content

- forums: moderately active, decent size community

[](http://www.carnivorousplants.org/)<u>[http://www.carnivorousplants.org/](http://www.carnivorousplants.org/)</u> - International Society of Carnivorous Plants

- website and forums

- website; decent resources section; lots of links out; great ‘about’ pages (check out member profiles page)

- forums: highly active, big

-cf [](http://www.tomatoville.com/)<u>[http://www.tomatoville.com/](http://www.tomatoville.com/)</u> for eg of forums-only approach: [](http://icps.proboards.com/)http://icps.proboards.com/

[](http://www.diydrones.com/)<u>[http://www.diydrones.com/](http://www.diydrones.com/)</u> - community on building UAVs

- website and forums

- website: based on Ning platform; all pages are ‘’blog’’ posts, postable by anyone

- a core group does most posts on site

- lots of reference material

- (has a store/commercial element; which was a spin-off of the community (not other way around)) 

- forums: huge, active

[](http://leatherworker.net/content/index.php/about/)<u>[http://leatherworker.net/content/index.php/about/](http://leatherworker.net/content/index.php/about/)</u> - leatherworking

- website: small amount of tutorials; large amount of blog postings

- froums

[](http://www.freerunning.net/de/das-freerunningnet-team-stellt-sich-vor)<u>[http://www.freerunning.net/de/das-freerunningnet-team-stellt-sich-vor](http://www.freerunning.net/de/das-freerunningnet-team-stellt-sich-vor)</u>:

- team of 7; website AND forums (famjam.org/forum - old posts, phaps using facebook group now? 400+ members, sim size community to us?)

(maybe bad exaple - not exchanging info…)

- small amount of articles

- small but solid amount of philosophy/about

- reasonable blog

[](http://aeroquad.com/)<u>[http://aeroquad.com/](http://aeroquad.com/)</u> - open-source aeroquad project

- website, wiki, forums

- has a store element