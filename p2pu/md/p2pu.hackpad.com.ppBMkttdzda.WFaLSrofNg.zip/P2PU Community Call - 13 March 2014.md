# P2PU Community Call - 13 March 2014

We're hanging out here: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYdAzFM1u6JvIldARbbkibs6NwA7v2xDKXrxYYvd3vqcLHy_JQ?authuser=1&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYdAzFM1u6JvIldARbbkibs6NwA7v2xDKXrxYYvd3vqcLHy_JQ?authuser=1&hl=en

Join us!

**Attendees**

*   Bekka
*   [Dirk Uys](/ep/profile/ppBMkttdzda)
*   [Philipp Schmidt](/ep/profile/Dc7zU8svumi)
*   [Erika Pogorelc](/ep/profile/oTNkHa0lFrI)
*   [Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)
*   [Carl Ruppin](/ep/profile/mNzH4UoHZhs)

**The P2PU Weekly Roundup - see Project Pad**

*   UPDATE: New format for this call: P2PU now doing a 'project call' at 10am EST Thursdays (1hr before this call) to report on work in progress and discuss specific projects

**Discussion**

Question about how-to do hangout on air calls for P2PU

*   I literally cannot understand how this works

Would like to hear a bit re how DML panel went

*   Slides [](http://www.slideshare.net/VanessaGennarelli/play-withyourmooc)http://www.slideshare.net/VanessaGennarelli/play-withyourmooc

Community Call Guest List - this might take a bit of time to schedule, but here's the wish  list

*   June re: data
*   Jonathan Worth! 
*   Carl and Jane re: licensing
*   Jane: School of Open
*   Doug Belshaw
*   Dave Cormier: Rhizomatic Learning
*   Alex - re experience of PWYM
*   Dirk on MechMOOC setup
*   HTH/others re DLMOOC
*   Jane re SoO general discussions/community/thinking/direction
*   ScoDa someone discussion on their community/activities
*   Srishti (and maybe others) on using Unhangout for online social learning
*   Avi Kaplan / Temple University on motivation
*   Wider community-driven folks (not just learning) to learn about other communities of practice? (Yoga, Stack Overflow, Ravelry)
*   Marisa Ponti (again)
*   Maybe some more traditional folks? To check in with peeps who are thinking differently about this? +1

ED Search Update

Course on open social learning

IFTTT

Blogpost -> 

*   share via: twitter, facebook, email [existing community list; staff; lernanta email list?? not without further checking], thepeople??

Response via twitter ->

*   notify ?? via email?

P2PU Mentions (blogposts, videos, media, presentations) ->

*   share
*   update evernote record / press clippings file

When we upload a youtube video

*   share

Community call reminder

*   share
*   update thepeople 

Conference recordings/slidedecks ->

*   share
*