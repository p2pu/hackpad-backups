# It's undoubting observing a fact, but changes occuring at the additional/substraction of substances  

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!