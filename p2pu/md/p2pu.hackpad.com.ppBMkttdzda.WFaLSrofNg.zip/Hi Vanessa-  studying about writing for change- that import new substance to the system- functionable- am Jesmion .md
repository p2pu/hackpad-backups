# Hi Vanessa,  studying about writing for change, that import new substance to the system, functionable, am Jesmion 

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!