# Tech notes 2015-05-04

*   We have to move fast (do something regarding overall tech each week)
*   We have to measure our success (design feedback loops)

This week: 

*   Setup p2pu.org homepage on AWS S3, 
*   configure redirects for lernanta part and 
*   update badges.p2pu.org to authenticate against courses.p2pu.org.
*   register *.p2pu.org SSL certificate

Next week

*   deploy changes