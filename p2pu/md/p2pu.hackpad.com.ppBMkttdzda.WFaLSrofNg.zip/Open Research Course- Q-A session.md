# Open Research Course: Q&A session 

**This Hackpad is for the Open Research course Q&A session that will take place on Thursday 11 September 2014 between 15.00-16.00BST. We will be recording the Google Hangout, but for those who are unable to join us, you can ask questions below or tweet on the course hashtag #openresearch **

Hi everyone, Beck here. I'll be online at 15.00BST today but in the meantime if you have a question about the course and what we'll be covering, please feel free to ask below. I'll then answer these during the session later. Thanks! 

If you would like to ask a question on the Hangout, the link is: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXAdhrTCmDhfPQ9NUr5SA)[https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXAdhrTCmDhfPQ9NUr5SA](/hXkL8h2W9Ac#https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXAdhrTCmDhfPQ9NUr5SA-)[ ](/hXkL8h2W9Ac#https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXAdhrTCmDhfPQ9NUr5SA-)

thank you!

Thanks to everyone who participated in today's call. To watch the recording, check out: [](http://youtu.be/5oUyA5hLnsI?list=PLVQl1nUupmrEQ9_LtuOYPS62dCXKMwxD6)http://youtu.be/5oUyA5hLnsI?list=PLVQl1nUupmrEQ9_LtuOYPS62dCXKMwxD6