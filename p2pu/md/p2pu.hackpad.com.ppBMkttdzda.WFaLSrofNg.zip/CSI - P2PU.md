# CSI + P2PU

Meeting--Unhangout: [](https://unhangout.media.mit.edu/h/vanessa)https://unhangout.media.mit.edu/h/vanessa

Attendees:

*   [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD) (P2PU)
*   Dave Kranenburg (CSI)

Agenda:

*   P2PU overview
*   CSI program vision

        *   Dave--2 years ago: education that happens in this space
    *   Don't want to provide content-->so much happening in events (750 events/year)--face-to-face learning experiences
    *   700 member organizations--a hub for people who want to educate
    *   Problems:

                *   Confusion--difference between member/community events and CSI events
        *   Overwhelmed by amount of content

        *   Rockefeller Foundation--funded

                *   package content, curation, and provide learning paths

        *   People attending review the presenter and the content--new and untested (learn at your own risk)
    *   Milestones: stage in development--coherence and structure to the infinite numbers

*   Writing for Change

        *   [Writing for Change](/fb4QHG43e1Q)

[CSI P2PU](/0W7V4ngAzp9)

[](http://reports.p2pu.org/reports/PWYM/)[http://reports.p2pu.org/reports/PWYM/](http://reports.p2pu.org/reports/PWYM/)

[](http://training.webmakerprototypes.org/en/)<u>[http://training.webmakerprototypes.org/en/](http://training.webmakerprototypes.org/en/)</u>