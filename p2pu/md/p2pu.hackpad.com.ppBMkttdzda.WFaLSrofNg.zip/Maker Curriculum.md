# Maker Curriculum

Maybe this is a better place to continue a conversation that I started [over here](/OnOff-Make-wfySMgBetc4)?