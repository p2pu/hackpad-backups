#  8 May Community call

**Attendees:**

**Staff Report backs**

Carl: 

Hewlett Grantees meeting - will be following up with various people over the next few weeks

Finance stuff - trying to close out 2013 accounts

2014 invoices

preparing for small finance audit needed before we do the DML invoice

Interim Hewlett report due mid-July so need to do some prep for that, and for a new Hewlett midsets-type grant. 

Dirk: 

Been on holiday. Now I have to think about stuff

Need to catch up with laura on teach the web

Nobody is shouting at me so that's good.

Spent yesterday catching missing etherpads, and setting up database for them

Will be working on open learning, teach the web and PWYM

Bekka

[Philipp](/ep/profile/yUEfaoK1a1N)

A bunch of admin stuff during office hours

Speaking to Ahrash and Carl about next steps from hewlett

LCL had last live seminar so preparing wrap up for that (Still thinking about the report)

**Discussion**