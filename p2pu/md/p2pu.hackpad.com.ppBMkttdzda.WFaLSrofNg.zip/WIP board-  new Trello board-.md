*   WIP board:  new Trello board: 
*   [](https://trello.com/b/8NlzI2nG/wip)**[https://trello.com/b/8NlzI2nG/wip](https://trello.com/b/8NlzI2nG/wip)**
*   Feedback:  

        *   needs visual indicator of change, priorities

**