# Gods of Mayhem and me

I am still feeling a bit clumsy with hackpad but I'm not going to give up.  I have been hard at work developing some key connections for Free Code Camp while I find the answers to some of my own projects questions. 

I am very grateful to have come across P2PU and then the Webmaker Training project where I have connected with Lucy.

I will still be helping with Free Code Camp however, I am going to be placing more focus on developing my project and I think working with the Mozilla/P2PU community is the best way to accomplish my goals.  Here I am finding the tools I need to get what I am looking for completed - its just a bit overwhelming to navigate without a map from people who are already plugged in so I created this hackpad for people who wish to help me are able to let me know until I get better at working with the community.

I am working to get my Webmaker Builder badge by creating a Teaching Kit on the design and development of your website.  Based off the article, "[Talking to your web designer - Part One](http://whitefusemedia.com/blog/talking-your-web-designer-part-one)" and "[Dark Patterns Are Everywhere: How to Stay Informed and Keep Them Out of Your Nonprofit Website](http://whitefusemedia.com/blog/dark-patterns-are-everywhere-how-stay-informed-and-keep-them-out-your-nonprofit-website)"

Using the development of my website as an example

**Request for feedback:** 

1.  Currently the slider on the Gods of Mayhem [page](http://godsofmayhem.com) has 4 mood images.  What do these images say to you?
2.  In your own words, what do the following statements mean to you?

        1.  Taking the Trash out of gaming
    2.  Keep Chaos and Manage Mayhem
    3.  We want to make you WATCH eSports

3.  Do these statements fit into the idea the mood images gave you?
4.  Do you know what a wireframe is?  Do you think the wireframe relates to how the site feels or how it works?
5.  What kind of information would you expect from a site that aims to show you how to make money in eSports?

        1.  How to be a professional player?
    2.  How to get funded, sponsored - paid salary?
    3.  What are the opportunities: player, coach, caster, personality, analyst, event coordinator, social media, etc.?

6.  Is it necessary to create a new and specialized community or just be able to have your viewers connect to each other (hashtags or twitter lists)?

I am open to help the P2PU staff - just have to hold my hand and lead me for awhile so I can get the hang of it :)

Merry Xmas!!! 

Hey [Nique Devereaux](/ep/profile/sv8yLN0uWO4) - just stumbled across this. You should post these questions to the forum - [](http://community.p2pu.org/)http://community.p2pu.org/.

Thank you I just posted it :)