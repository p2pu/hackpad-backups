# Starting a Community Call

Log in to your P2PU google account, and go to G+

*   Can this be any @p2pu.org account?
*   yup, it can. As long as you have an [p2pu account, you should be golden. ](/eb4UaJGKV5P#p2pu-account,-you-should-be-golden.-)
*   Have you tried changing your profile in the top right as the P2PU page?

Update: [](https://www.youtube.com/watch?v=HepNNU8L68Q)https://www.youtube.com/watch?v=HepNNU8L68Q

Click the Home menu:

![](https://hackpad-attachments.s3.amazonaws.com/hackpad.com_siWKeO4pPY7_p.76178_1393341191765_hangout.jpg)

Select the Hangout option:

![](https://hackpad-attachments.s3.amazonaws.com/hackpad.com_siWKeO4pPY7_p.76178_1393341444692_hangout2.jpg)

Start a Hangout on Air, name it, share the link in the pad, and go live!

Hangout will automatically be broadcast and then uploaded into our YouTube channel.