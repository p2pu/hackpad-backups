# littleBits Revised Module Template

**For team up with others: (embed in their track AND put in the weekly email)**

1.  Module 1: Attend Community call
2.  Module 2: Ask for feedback / Give someone feedback (on project page)

Ask in the project discussion / give on the feedback page (and directions for feedback)

By the end of the course you;ve made 2 things and run 1 event

midway through the course we make it clear that you are going to run an event--> 

1. Module 3: hold the event-->find other bitsters in your hood-->one lesson upload

remix the event guide-->make your own event plan-->upload to lessons page

Week 1:

Week 2: 

*   CTAs: per tent

        *   First Design Challenge
    *   First Discussion Prompt

*   Unhangout: Learning Activity Design + Remixing

Week 3:

*   CTAs: per tent

        *   Second Design Challenge
    *   Second Discussion Prompt

*   Unhangout: Event Design + Privacy

Week 4: Building an Audience + Codesign/Participatory Design

*   CTA: per tent

        *   Remix for a Group Event Design Challenge
    *   Third Discussion Prompt

*   Unhangout: Building an Audience + Codesign/Participatory Design

Week 5: 

*   CTA:

        *   Reflection on learnings in InventFest

*   Unhangout: Documentation + Harvesting