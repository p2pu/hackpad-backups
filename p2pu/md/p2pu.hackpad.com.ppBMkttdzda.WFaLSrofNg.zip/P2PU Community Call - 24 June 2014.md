# P2PU Community Call - 24 June 2014

**Attendees**

*   [Bekka Kahn](/ep/profile/BT4g65BvPRV)
*   [Philipp Schmidt](/ep/profile/Dc7zU8svumi)
*   [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)
*   [Erika Pogorelc](/ep/profile/HgL1VSf8fsX)
*   [Carl Ruppin](/ep/profile/mNzH4UoHZhs)
*   [Dirk Uys](/ep/profile/ppBMkttdzda)

**Agenda**

*   We are doing a project review using our Projects trello board
*   [](https://trello.com/b/8NlzI2nG/wip)https://trello.com/b/8NlzI2nG/wip

[Carl Ruppin](/ep/profile/mNzH4UoHZhs)

*   Thinking more about the CC 4.0 upgrade - has sent a mail to everyone with process and next steps
*   Working on moving website development and June's grant further forward. 

**Dirk Uys**

*   Working a lot on proptyping ideas for where courses will go to - nothing ready tos hare yet, but hopefully soon. 
*   Working on Social LEarnig course - although that's been pushed back
*   Working on Internet of Things project - timeframes, courses, etc - set to start in September, but nothing concrete yet
*   Webmaker training with Mozilla - tying up a few loose ends - overall a good experience. 

[Erika Pogorelc](/ep/profile/HgL1VSf8fsX)

Watching a lot of football (go ghana!)

Working on the website to bring it in line with the new strategy - 

School of Open - a few things to talk to Jane about - setting up their own channels

[Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)

Working on online marketing and strategy - divvied up the tasks with Bekka and Erika 

Working on badge alliance with Erin 

Research project for writing MOOC - document has arrived from Beck Pitt at OER HUB - still waiting to hear back

Splashpage for Roundtable has been useful - 