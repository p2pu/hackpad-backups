# Course in a Box 1.0

## Signup: 

*   signup with name and email
*   send emails to signups
*   schedule emails
*   see number of signups

MechMOOC

*   N Have to deploy to Heroku per course
*   N Have to customize signup email in code
*   P 

MailChimp

## Agenda 2015-02-03

*   go through the document 

        *   sticky points

                *   Not linear

*   What are the things that needs to be done?

    *

*   How do we distribute the work

Next steps:

*   Get concrete on audience - who, where will you get those people?
*   Write out a user stories

## Agenda - 2015-01-13

The plan

*   Launch big and public
*   Launch date: Week of 2nd Feb?

## Goals

20-50 people who actually work through it

~200-400 people to sign up 

## Reds:

*   [Dirk Uys](/ep/profile/ppBMkttdzda): 

        *   facilitation
    *   weekly meetings
    *   he's not a make people do stuff, whip-cracking kinda guy. By fucking up people will learn about it. 
    *   community-building is really hard, a bit of burn out
    *   wants to focus on tools and tech
    *   in CiAB people aren't connecting enough
    *   ~60 people have signed up
    *   It doesn't feel social enough

*   [Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)

        *   Is PURL something people want?
    *   is our team learning how to collect and interpret feedback?
    *   synchronous chat?

*   [Carl Ruppin](/ep/profile/mNzH4UoHZhs):

        *   are we spinning our wheels?
    *   let's play to our strengths: a technical product
    *   are we thinking: this will only work if we have 100 people...
    *   carl: we need more content--

                *   create conversations we own
        *   double-down on content

## Suggestions:

*    Surfacing social aspect on the splash page

        *   Hangouts
    *   Discourse conversations

*   Different modules are the different stages of the course that you are at in creation
*   **Make PURL modular: Make different modules for the stage in the course creation / community - building stage in the process that you're in**

**Next steps:**

*   follow up conversation, maybe a later launch date?

What do we need to do to be ready for launch?

*   compare against Mechanical MOOC: what more do we want out of this?

*   Calendar update
*   Goals for partnerships and success metrics
*   Metrics and measurement
*   Harvest case studies

What tools are we missing?

*   A way to manage signups for courses people create using _Course in a Box_ (not everyone wants people to fork their courses)

What do we want to add to the course?

*   Git/GitHub guide for educators
*   Better mechanism for feedback
*   Complete the feedback protocol
*   Badges
*   A map for people doing Course in a Box to add themselves
*   Something to encourage people to form their own community identity)

Marketing strategy

*   Work with Elliot
*   Feedback loop: email 2 days after signup "welcome",  can we ask you two quick questions, find out where it provides value
*   Digest for discourse
*   Which awards should we aim for?

Other questions?

*   Should we use the same Trello workflow - eg create a template board for running the course?