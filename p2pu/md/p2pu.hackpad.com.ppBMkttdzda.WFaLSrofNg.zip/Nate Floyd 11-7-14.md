# Nate Floyd 11/7/14

Nate: 2 year volunteer program in Belize City; placed in community center, doing training in basic skills getting to employability. Got a hybrid program with local bank offering 3 day work, and 2 day trianing in the center.

Want to build a lower-burden, online, self-learning traininng program.