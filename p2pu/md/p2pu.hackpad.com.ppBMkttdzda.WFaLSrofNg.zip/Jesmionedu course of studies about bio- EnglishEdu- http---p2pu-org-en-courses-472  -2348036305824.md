# Jesmionedu course of studies about bio, EnglishEdu, [](http://p2pu.org/en/courses/472)http://p2pu.org/en/courses/472  +2348036305824

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!