# TK + VMG

the CRI

6 main projects and ~20 people

Anchored in biology: digital stuff and education

"Everyone is born a researcher" François Taddei, Director

Collective intelligence → social insects/boids/pedestrian movements

Trying to start something like the hive learning networks but directed toward research, digital litteracy and city/citizenship. Potential partnership with city of Paris and Mozilla Foundation. We are drafting the blueprint of what could be hive.paris as a web platform (it started as a cMOOC about web litteracy). In fact, that is my next two months project (:

Course in a Box: [](http://howto.p2pu.org/)http://howto.p2pu.org/

Example: Codecatz: [](http://ercchy.github.io/get-codecatz-smart/)http://ercchy.github.io/get-codecatz-smart/

P2PU Definition of Community: [](http://info.p2pu.org/2014/09/29/writing-for-change-pre-course-survey/)http://info.p2pu.org/2014/09/29/writing-for-change-pre-course-survey/

Tools for historians to engage data + Digital Humanities

Scratch for data-->get people to use play

Scratch for visualization-->

Data Literacy + Co-building Environments

[](http://www.librarieswithoutborders.org/index.php/news-and-events/lwb-news/item/291-the-ideas-box-a-portable-multi-media-kit-for-refugees)http://www.librarieswithoutborders.org/index.php/news-and-events/lwb-news/item/291-the-ideas-box-a-portable-multi-media-kit-for-refugees

*   TK: we try to hack the ideabox to add a toolbox for users to produce their own online learning materials. Right now it is mainly about producing a video course about best practice in filming. I have to digg into mechanical mooc to also see if their work to do in order to facilitate people operating their own MOOCs as p2p local practice.

- [the master FOSTER](http://cri-paris.org/fostermaster/) program that starts this year and is focused on edtech and innovation but some us try to divert them toward open education social values

- [Nightscience](http://nightscience.org/about/) an annual event about creativity and scientific discovery

+ Knight Foundation: Online + Offline

+ Data Project

recontact  organizers of open source typography workshop

*    [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD): what is the text about the benefits of openness you talk me?