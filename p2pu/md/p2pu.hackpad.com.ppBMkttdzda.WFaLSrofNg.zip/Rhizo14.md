# Rhizo14

Reflections on Unhangout

-transitioning is difficult

-slider in hangout on air (people were in different parts of the conversation and it was difficult)

-don't try to do it too quickly---comments are more profound in the blogging process

Next time:

-use 2 computers to drop into each room---difficult to get the tone of each room

Assigning people adminstrators on the various platforms has been helpful

Awesome shit: [](http://hawksey.info/tagsexplorer/?key=tDHgQeSbHR3fcvN81EHnxQQ&sheet=oaw)http://hawksey.info/tagsexplorer/?key=tDHgQeSbHR3fcvN81EHnxQQ&sheet=oaw

People like their platforms--but p2pu is the central place to shape the conversation for the week

but people use the platform that they prefer

When does the course end?

So much momentum--set it free and let the connections grow

People are talking about membership in a MOOC as something that they immediately recognize-->noticing literacies

IFFTT--need simple stitching to keep the flow of ideas going. Helps one idea to go everywhere. How can you keep the information flowing between communities

No one that's native to P2PU as platform: 

Artifact from session:

[](https://docs.google.com/presentation/d/1mMlAshWULTGlwyojWr4PsiJaMhCAG0FCF0MPXXmjJuM/edit#slide=id.g2a177ffba_021)https://docs.google.com/presentation/d/1mMlAshWULTGlwyojWr4PsiJaMhCAG0FCF0MPXXmjJuM/edit#slide=id.g2a177ffba_021

Going well in the course

Concerns in the course

What are the requirements for a rhizomatic course?

Blog Posts about the course:

[](http://lastrefugelmu.blogspot.co.uk/2014/01/rhizo14-community-is-curriculum.html)http://lastrefugelmu.blogspot.co.uk/2014/01/rhizo14-community-is-curriculum.html

[](http://sco.lt/4iqdE1)http://sco.lt/4iqdE1

[](http://connectiv.wordpress.com/2014/01/16/a-rhizomatic-teaching-story-to-show-my-idea-of-rhizomatic-learning/)http://connectiv.wordpress.com/2014/01/16/a-rhizomatic-teaching-story-to-show-my-idea-of-rhizomatic-learning/

[](http://ahnjune.com/?p=1136)http://ahnjune.com/?p=1136