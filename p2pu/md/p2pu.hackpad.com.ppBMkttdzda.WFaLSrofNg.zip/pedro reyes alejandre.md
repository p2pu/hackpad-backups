# pedro reyes alejandre

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!

[](http://osi.xwiki.com/bin/Main/UserDirectory?viewer=comments#xwikicomment_0)http://osi.xwiki.com/bin/Main/UserDirectory?viewer=comments#xwikicomment_0