# BK Office Hours

3 February 2014

Today I'm going to be talking about/thinking about/working on:

*   Google adwords (what we have, what we want to do, how the hell to do it)

        *   DU: Things to consider:
    *   1. where do we want to drive traffic
    *   2. staying within the TOS of the ad grant - we can direct to other domains, I don't know if subdomains are fine
    *   Resources from Google: [](https://support.google.com/grants/answer/98870?hl=en&ref_topic=3500140)https://support.google.com/grants/answer/98870?hl=en&ref_topic=3500140

*   <s>Promo copy for assessment report</s>
*   Data Release: Sarah and June have put it all together, I'm trying to wrap my brain around it so that we can make this public
*   Updating the Comms Trello as per the community call last week. 