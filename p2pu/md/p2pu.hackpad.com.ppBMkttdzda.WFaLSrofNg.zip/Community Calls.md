# Community Calls

*   Marieke Guy - OKFN's Open Ed person, and co-ordinator for the LinkedUp projects 
*   Researchers: 

        *   June Ahn - an update on the regular research discussions 
    *   Thieme Hennis 

*   Unhangout team 
*   Course organisers (for some public love and to tell us about their experiences)

*   How to track and share P2PU media
*   Music MOOC Overview / Launch
*   P2PU Strategy (before Oct/18) and after board meeting (Oct/18)

**Dates / Scheduling**

Oct/10

*   P2PU strategy discussion (final session pre board meeting)

Oct/17

*   ...

Oct/24

*   P2PU strategy (post board meeting)