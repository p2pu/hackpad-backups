# Community call

**When: **Thursday, 11am EDT

**Where:  [ ]**

and here: [Community Call 22 May 2014](/9jCZYp4ZEds)

Future announcements and follow-ups will be at: [](http://thepeople.p2pu.org/category/org/community-calls)http://thepeople.p2pu.org/category/org/community-calls

**15 May Notes**

[P2PU Community Call 15 May 2014](/kqeEKM3W5XT)

Moved to [P2PU Community Call 15 May 2014](/kqeEKM3W5XT)

**8 May Notes**

[8 May Community call](/CNo7aebTpgi)

Notes:

*   Discourse by design silos information (no tagging, no sub-communities, no ...)
*   You only fully know what categories you need after you've given your community some time to interact
*   Vanessa redesigned the P2PU discourse around four user profiles / needs

        *   People who want technical info
    *   Learning support
    *   Curious about the org

*   Need to strike a balance between community building and content building
*   LCL Categories started with simple verbs - meet, share, ask

Questions:

*   I'm curious if nascent communities need a different approach than maturing or mature communities.
*   In the P2PU use case: Can we replace email with discourse?