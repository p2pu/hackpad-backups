# Data Mooc Ideas

Problem Set

Devs are gods-->devs want to keep it there

Start with spreadsheets-->BORING

More people need to learn this than the traditional audience

Solution Set

Storyteller + Visual Artist + Coder

Make it less scary

John Willbanks--early days creative commons / open personal medicine

Find a common design language

Aaron Schwartz Documentary hosting 

Kaitlin Thaney: 

Blog Post about open data

Aaron Schwartz video with dutch designer

John Willbanks--early days creative commons / open personal medicine

JGL movie about CC remix

Vanessa to send:

Writing for Change