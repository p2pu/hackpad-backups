# Notes on Discourse

Settings:

*   Set all users to trust level 1 so they can change their avatar

Messages:

*   Just learned that I can send messages to **entire groups** in Discourse.
*   You are a moderator and I just mass messaged all the moderators. This is a big deal because it means we can mass issue badges, mass encourage lurkers and newbies, mass congratulate super mentors and otherwise use discourse to start little by little replacing other, less organizable, metricable, usable communication systems.
*   [](http://discourse.webmakerprototypes.org/t/mass-messaging-user-types-in-discourse/512)http://discourse.webmakerprototypes.org/t/mass-messaging-user-types-in-discourse/512

[Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)

*   Keep several courses in one discourse if you can--if you do multiple installs, you lose your profile and trust levels. 
*   Design: ways to make your wordpress/banner match your discourse
*   Emergent groups vs structured groups 
*   Categories are silos & there are no tags