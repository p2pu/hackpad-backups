# Erika

Learning wishlist:

*   Google Analytics
*   Wordpress Essential Training
*   Node.js

        *   [](http://pragprog.com/book/jwnode/node-js-the-right-way)[http://pragprog.com/book/jwnode/node-js-the-right-way](http://pragprog.com/book/jwnode/node-js-the-right-way)

*   Frontend libraries (Can.js, angular.js, backbone.js)
*   Preporcessors (Coffescript, Jade,)
*   WebGL
*   HTML5

        *   geolocation
    *   canvas
    *   getUserMedia

*   NoSQL DB

        *   MongoDB
    *   CouchDB

*   [](http://ionicframework.com/)[http://ionicframework.com/](http://ionicframework.com/)

**Parking Lot**

GovLab Academy project

*   if they accept the long term collaboration we will continue with it
*   List of task of bugfixes and feature requests
*   Set up trello board
*   Ask Cosmo about Stories page

*   Create github for wordpress for schools

P2PU Widget Documentation in GitHub

TheGovLab documentation on GitHub

**25 - 28 November**

*   Reports documentation
*   OCWC Talk Proposal

*   Take a look into efforts to moving thegovlabacademy.org to their own dreamhost account

*   Make etherpad read only pad.p2pu.org

*   P2PU Web Properties document (look over)
*   Some of the stats for Badges by Monday
*   DL MOOC meeting (starting in mid January)
*   Talking about music mooc

*   We are spending a lot of emails on errors that are produced by Django 1.4 on Badges. 

**11- 17 November**

1.  Archive project:

1.  Hackpad backup

1.  Etherpad backup (

1.  Reports

1.  Home Page

**17 - 31 October**

Thegovlab project

[GovLab Academy](/govlab)

**14 - 18 October**

Schools home page

some css love to classgalery

*

**23 - 27 September**

Progress

*   selenium test installed and working
*   Travis CI alingment with selenium tests 

Priorities

*   Dashboard 

        *   I had talked with VMG and we decided that is a good direction that we are going now

*   I will do some work on reports next week

Problems

*   DLMooc has a design problem on mobile view

**19 September**

Progress

*   Badges
*   Allow editing of requirements after it has been published
*   Check availability of Badge title with ajax
*   P2PU course can be linked within requirements field
*   Question with Badge collections is still "hanging"
*   Browser testing
*   with one account which we could all use price is 19$/month

        *   we can cancel anytime (it runs until end of billing period)
    *   we have to get new subscription for next time we want to use services

*   AWS Console asscess (for Philipp personal account)
*   Video to create new users for console: [](http://docs.aws.amazon.com/IAM/latest/UserGuide/IAM_Introduction.html)[http://docs.aws.amazon.com/IAM/latest/UserGuide/IAM_Introduction.html](http://docs.aws.amazon.com/IAM/latest/UserGuide/IAM_Introduction.html) 
*   interesting reaading: [](http://aws.amazon.com/cli/)[http://aws.amazon.com/cli/](http://aws.amazon.com/cli/)

Problems

**13 September**

Progress

*   Homepage design review
*   DLMOOC CSS -> CSS Framework

        *   remove github stuff, make partners page, put p2pu logo on the right, move signup above description, add conference logo

Priorities

*   Badges:

        *   discoverability - sort and filter
    *   improving use of dashboard (VMG has wireframes, she is doing testing)
    *   Doing all sors of improvments for Badges
    *   LRMI data upon creating a Badge

*   SOO Homepage
*   Find "home" for Research project

**Aug 27**

Progress

*   Fix major bugs on home page for the responsive design

        *   Blog integration
    *   Make it easy to get to dashboard

*   Reports update -> Create a reports landing page (and add 2nd report)

        *   Home page for reports
    *   Reports for School of Ed

*   Top navigation bar (plug-in is done, waiting for Dirk to discuss)
*   [Maybe] Badges fixes based on feedback from Karen Fasimpaur

Priorities

*   <s>Keep an eye on archive.p2pu.org to see if the DNS update fixed it</s>
*   Deploy top navigation bar (Waiting for Dirk to discuss)
*   Badges:

        *   discoverability - sort and filter
    *   improving use of dashboard (VMG has wireframes, she is doing testing)
    *   Doing all sors of improvments for Badges

*   <s>Homepage design review (didn't get to it last week)</s>
*   Badges CSS -> CSS Framework
*   <s>DLMOOC CSS -> CSS Framework</s>

        *   <s>remove github stuff</s>, make partners page, p<s>ut p2pu logo on the righ</s>t, <s>move signup above description, add conference logo</s>

*   Follow up Nadeem

**Aug 20**

Progress

*   Holidays!!!

Priorities

*   <s>Fix major bugs on home page for the responsive design</s>

        *   <s>Blog integration</s>
    *   <s>Make it easy to get to dashboard</s>

*   <s>Reports update -> Create a reports landing page (and add 2nd report)</s>

        *   <s>Home page for reports</s>
    *   <s>Reports for School of Ed</s>

*   <s>Top navigation bar</s>
*   <s>[Maybe] Badges fixes based on feedback from Karen Fasimpaur</s>
*   (Philipp/Erika design review of homepage -> next Monday)
*   Follow up with Nadeem

Process

Problems

Badges issues:

*   Change browse badges to apply for a badge
*   Sort and filter based on subject and school

        *   Most recent/most awarded

*   Change dashboard to my stuff/my peers stuff
*   Show thumbnail of badge in project submission
*   Change email notification copy for experts to be more call-to actiony

Invoicing process

*   send banking details to money@p2pu.org

        *   bank name
    *   adress
    *   SWIFT/BIC
    *   account number

*   send invoice by 25th in month

Goals