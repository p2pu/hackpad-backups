# P2PU Google Analytics

## p2pu.org

What do we want people to do?

*   Read more about us
*   Want to contact us
*   Share the site on social media
*   I would like to tell more about me(means bio) and my goals for doing a particular course
*   [](http://whitefusemedia.com/blog/5-steps-creating-charity-website-measurement-plan-google-analytics-free-template)http://whitefusemedia.com/blog/5-steps-creating-charity-website-measurement-plan-google-analytics-free-template

## community.p2pu.org

What do we want people to do?

*   Read posts from other people
*   Post new content
*   Search for content / find useful info using search engines

## howto.p2pu.org

What do we want people to do?

*   Sign up for the course
*   Get more badges
*   Gain skills to change their lives by improving or creating a career path, encouraging continuous learning and providing useful information to keep courses up-to-date and relavent