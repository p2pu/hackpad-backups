# P2PU Community Call Guest-list

This is where we'll be collating the upcoming guest list for P2PU Community Calls (what take place every Thursday).

If you'd like to speak to the community (or have been invited but haven't locked down a date) feel free to pick one here: 

27 March - Beck Pitt (Open University, OER Research hub) discussing research conducted with School of Open

*   Pre call prep: please read blog posts [Part 1](http://oerresearchhub.org/2014/03/10/school-of-open-research-findings-part-i/)  and [Part II](http://oerresearchhub.org/2014/03/14/school-of-open-research-findings-part-ii/)

3 April - Peer Learning: revisiting what it is, why we believe in it, how we do it. 

*   Pre-call prep:

10 April

17 April - [Carl Ruppin](/ep/profile/mNzH4UoHZhs) and Jane Park - Licensing discussion

*   Pre-call Prep: Please read some of the following:
*   [Summary of licence updates updates](https://creativecommons.org/Version4)
*   * slide show on CC [4.0 for education ](http://www.slideshare.net/janeatcc/open-ed-week-v40-for-education)

24 April

1 May

8 May

15 May

22 May

29 May

Wishlist for future community calls?

*   Conversation about how to start a school - possible guests: Ralfe, Jane & Karen
*   Talk with [](http://www.raspberrypi.org/)http://www.raspberrypi.org/ about their educational initiatives (or about community)?