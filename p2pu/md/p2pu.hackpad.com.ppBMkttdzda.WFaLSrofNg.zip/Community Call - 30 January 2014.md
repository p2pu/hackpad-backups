# Community Call - 30 January 2014

We're hanging out here: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYdeAbg4rHze-oKiQDnZu4GkNG1VV97i3OQ4CFRwQXnsWhDuhw?authuser=1&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYdeAbg4rHze-oKiQDnZu4GkNG1VV97i3OQ4CFRwQXnsWhDuhw?authuser=1&hl=en - join us! 

**Attendees**

*   Dirk
*   Philipp
*   [Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)
*   Bekka Kahn
*   [Erika Pogorelc](/ep/profile/oTNkHa0lFrI) 

*   New format: an experiment 

**The P2PU Weekly **

**Agenda for discussion**

*   BK: report back from last week - community list stats & IFTTT usage

        *   p2pucommunity: 412 people
    *   thepeople.p2pu.org

                *   Unique visitors: 1178 (GA)
        *   Total visits: 2572 (GA)
        *   1033 posts in 209 topics
        *   133 users

*   P: Timetracking - Is anyone still doing it? Is it useful? How are we doing it?

        *   Doing it, but some days goes better than others. It helps me a lot being intentional about my time
    *   Doing it, find it v useful.  Needs to be done in realtime (as you go) or no better than just skipipng it relying on memory/estimation

*   P: How do we handle support overall (and specifically [](http://help.p2pu.org)http://help.p2pu.org - or maybe replace help.p2pu.org)
*   P: Use of community call and tech call going forward. 

        *   Goal: Continue to  minimize "meetings" but maximize "sharing and collaboration"
    *   Suggestion: 

                *   2 calls (both open to anyone)
        *   (up to) 1 hour "project call" - merged tech and community call
        *   (optional / as needed) 1 hour - community call for meta discussion and guests

*   C: big picture issues for discussion:

        *   openness vs transparency
    *   role of expertise in collaborative environments

*   Interesting conversations on OKFN/OER List re: using not-so-open tools like Google for MOOCs - blocked in various countries that the US doesn't like