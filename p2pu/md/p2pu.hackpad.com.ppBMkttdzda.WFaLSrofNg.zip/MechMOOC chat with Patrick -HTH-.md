# MechMOOC chat with Patrick (HTH)

Questions

*   How to import Google Course builder data into Mechanical MOOC:

        *   possible to import: [](https://github.com/p2pu/mechanical-mooc/blob/master/signup/management/commands/import_signup.py)https://github.com/p2pu/mechanical-mooc/blob/master/signup/management/commands/import_signup.py
    *   can we extract signup data from google course builder?

                *   [](https://code.google.com/p/course-builder/wiki/ExportCourseData)https://code.google.com/p/course-builder/wiki/ExportCourseData

*   [](http://newschoolcreation.appspot.com)http://newschoolcreation.appspot.com