# martinspad

* fühlt sich vom design her besser an als etherpad lite. was genau ist einfacher zu managen?

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!