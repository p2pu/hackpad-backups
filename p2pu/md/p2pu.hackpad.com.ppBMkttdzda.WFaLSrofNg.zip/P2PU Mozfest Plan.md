# P2PU Mozfest Plan

Priorities:

*   Meet with Gunner (as team)
*   Dirk Slater (pal o [Bekka Kahn](/ep/profile/BT4g65BvPRV))
*   Kelsey Wiens 
*   Data partners

[Carl Ruppin](/ep/profile/mNzH4UoHZhs):

[Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)

*   Art and the Web track--find Data partners
*   Meet w Kelsey

[Bekka Kahn](/ep/profile/BT4g65BvPRV)

[Erika Pogorelc](/ep/profile/oTNkHa0lFrI)