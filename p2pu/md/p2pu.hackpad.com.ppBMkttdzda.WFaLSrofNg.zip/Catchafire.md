# Catchafire

Add capacity to NFP's

Provide meaningful opportunities for professionals looking for short-term opportunity to work on something they're passionate about.

Started out as matchmaking service, grown into system that facilitates that but also educates on how to best engage volunteers, how to manage that relationship and how to structure the work to get a strong deliverable from the volunteer - good work, delivered on time.

Orgs

$500 setup fee to get up on their website and connect to their community

Then $199/mth while engaged in projects (noting most are 3-4mth projects), can pause

OR

$149/mth for a 12 mth commitment

we say 3-5weeks to get matched project-volunteer, but can be a couple of days, up to 5-6 weeks.  People apply answering 'why are you qualified' and 'why are you passionate' and if you like them you move to a phone interview.  Our advisors help with guiding orgs through how to do these kind of interviews, how to choose someone - setting goals, managing expectations, etc - wanting you to be self-sustaining in doing this kind of thing.