# Launch plan for Social Learning

*   [Bekka Kahn](/ep/profile/BT4g65BvPRV)
*   [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)

Background: 

*   Marketing Notes: [Online Marketing Strategy](/XJlUfnSWOeT)
*   Anatomy of a Perfect Blog Post: [](http://blog.bufferapp.com/perfect-blog-post-research-data?utm_campaign=utm_campaign=weekly_digest_week_2014W23_dormant_test_control)http://blog.bufferapp.com/perfect-blog-post-research-data?utm_campaign=utm_campaign=weekly_digest_week_2014W23_dormant_test_control
*   How to Really Launch in 2014: [](http://unicornfree.com/2014/dont-fave-this-post-how-to-really-launch-in-2014)http://unicornfree.com/2014/dont-fave-this-post-how-to-really-launch-in-2014

July 1 launch--run once a month

Teaser Blog Posts

Vanessa:

*   _How to find your crew online: Groups and Cohorts Online_
*   _How to measure the health of your community_
*   _How to scaffold collaboration in your online community_

[Bekka Kahn](/ep/profile/BT4g65BvPRV)

*   How to use tools that reflect open learning pedagogies
*   What would happen if power worked differently in learning? Does learning have to look like learning?

--->Start with a story

--->Call to action: sign up for social learning course

--->Jump into the blog and make choices from there:

Bekka to come up with a template / checklist-->x y z are necessary 

Roll out: 1 by the end of this week at least--Monday / Thursday

Content marketing approach, rather than announcement-type messaging

*   How to approach social learning
*   Tell a story
*   Headlines
*   Images