# P2PU Community Call - 13 Feb 2014

We're hanging out here: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYcWdnwjQ6R5fBtr03mHA77mROtx8FTj8N0yzKLteaS34cHNkQ?authuser=0&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYcWdnwjQ6R5fBtr03mHA77mROtx8FTj8N0yzKLteaS34cHNkQ?authuser=0&hl=en

 - join us! 

**Attendees**

*   [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) 
*   [Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi)
*   [Carl Ruppin](https://p2pu.hackpad.com/ep/profile/mNzH4UoHZhs)
*   [Dirk Uys](https://p2pu.hackpad.com/ep/profile/ppBMkttdzda)

**The P2PU Weekly Roundup - see Project Pad**

*   UPDATE: New format for this call: P2PU now doing a 'project call' at 10am EST Thursdays (1hr before this call) to report on work in progress and discuss specific projects

**Discussion**

Using one hackpad for Project Calls (not different pad each week)

*   [P2PU Project Call](https://p2pu.hackpad.com/5QyILCrcDdV)
*   Also use this hackpad to "park" ideas you want to discuss with others during the week

How are personal office hours going? Lessons learned? Strategies to share? 

*   New 'project call' hackpad for noting conversations/questions/etc want to discuss with specific people
*   Otherwise a success

Community discussions on thepeople:

*   Pretty slow week

Licences 

*   When you remix content (take existing content, but not adapt/modify) you can't apply a new license
*   The original underlying work stays licensed under original license