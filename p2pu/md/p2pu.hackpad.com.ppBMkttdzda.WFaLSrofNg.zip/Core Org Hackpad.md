# Core Org Hackpad

This conversation was moved into a private Google Doc (while we are working out the details). 

[](https://docs.google.com/a/p2pu.org/document/d/1g1kPUvFoRMN54Kz_9o1CwiycS-f5GpXA7yHuQWx1dlY/edit#)https://docs.google.com/a/p2pu.org/document/d/1g1kPUvFoRMN54Kz_9o1CwiycS-f5GpXA7yHuQWx1dlY/edit#