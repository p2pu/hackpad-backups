# @#PWYM Cohorts

Hi y'all, could you please link to your G+ community on this pad? We'd love to showcase what is happening in your stellar groups. 

Group 1:  [](https://plus.google.com/u/0/communities/110769185226388551448)[https://plus.google.com/u/0/communities/110769185226388551448](https://plus.google.com/u/0/communities/110769185226388551448)

Group 12: [](https://plus.google.com/communities/100158734963040570464)https://plus.google.com/communities/100158734963040570464

Group 21: [](https://plus.google.com/u/0/communities/105518193975868968376)[https://plus.google.com/u/0/communities/105518193975868968376](https://plus.google.com/u/0/communities/105518193975868968376)

Group 22: [](https://plus.google.com/communities/112060096018403671471)https://plus.google.com/communities/112060096018403671471

Group 33: [](https://plus.google.com/u/0/communities/102280041668414798347)https://plus.google.com/u/0/communities/102280041668414798347

Group 35: [](https://plus.google.com/communities/115905124305651001684)https://plus.google.com/communities/115905124305651001684

Group 39 [](https://plus.google.com/u/0/communities/103959397924064728916)https://plus.google.com/u/0/communities/103959397924064728916

Group 42: [](https://plus.google.com/u/0/communities/110838923069870904670)[https://plus.google.com/u/0/communities/110838923069870904670](https://plus.google.com/u/0/communities/110838923069870904670)

Group 46: [](https://plus.google.com/u/0/communities/106655362432812011770)[https://plus.google.com/u/0/communities/106655362432812011770](https://plus.google.com/u/0/communities/106655362432812011770)

Group 58: [](https://plus.google.com/communities/103478429520159108552)[https://plus.google.com/communities/103478429520159108552](https://plus.google.com/communities/103478429520159108552)

Group 59: [](https://plus.google.com/u/0/communities/111133434459755955516)https://plus.google.com/u/0/communities/111133434459755955516

Group 64: [](https://plus.google.com/u/0/communities/108699606771708605402)[https://plus.google.com/u/0/communities/108699606771708605402](https://plus.google.com/u/0/communities/108699606771708605402)

Group 68: [](https://plus.google.com/u/1/communities/104090256625687970997)[https://plus.google.com/u/1/communities/104090256625687970997](https://plus.google.com/u/1/communities/104090256625687970997)

Group 69: [](https://plus.google.com/u/0/communities/116559091052551593881)https://plus.google.com/u/0/communities/116559091052551593881

Group 70: [](https://plus.google.com/u/0/communities/100782300153949061424)[https://plus.google.com/u/0/communities/100782300153949061424](https://plus.google.com/u/0/communities/100782300153949061424)

Group 72 (is best): [](https://plus.google.com/communities/107646608064475964093)https://plus.google.com/communities/107646608064475964093

Group 80: [](https://plus.google.com/communities/113451819190696434615)https://plus.google.com/communities/113451819190696434615

Group 83: [](https://plus.google.com/communities/113125544850152904503)https://plus.google.com/communities/113125544850152904503

Group 89: [](https://plus.google.com/communities/117968975256364630309)[https://plus.google.com/communities/117968975256364630309](https://plus.google.com/communities/117968975256364630309)

Group 92: [](https://plus.google.com/communities/100249055808157640716)[https://plus.google.com/communities/100249055808157640716](https://plus.google.com/communities/100249055808157640716)

Group 108: [](https://plus.google.com/communities/111161227785117418044)[https://plus.google.com/communities/111161227785117418044](https://plus.google.com/communities/111161227785117418044)

Group 116: [](https://plus.google.com/communities/115794281414389936188)[https://plus.google.com/communities/115794281414389936188](https://plus.google.com/communities/115794281414389936188)

Group 118: [](https://plus.google.com/u/0/communities/112056957094320722574)https://plus.google.com/u/0/communities/112056957094320722574

Group 132:  [](https://plus.google.com/u/0/communities/101858095322203352029)[https://plus.google.com/u/0/communities/101858095322203352029](https://plus.google.com/u/0/communities/101858095322203352029)