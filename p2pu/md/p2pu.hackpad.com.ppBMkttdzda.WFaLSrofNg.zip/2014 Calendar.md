# 2014 Calendar

Jan

Feb

Mar

Apr

May

Jun

July

Aug

Sep

Oct

Nov 

Dec

SoO

SoW

IoT

P2PU-howto-course

P2PU-course-in-a-box

Labs?

Mindsets-stats

Mindsets-fiction

PWYM future?

GovLab future?

LCL iteration

SoE??

[conferences]

[P2P meetup]

PythonMOOC

DLMOOC