# P2PU Community Call - 24 April 2014

Good people of P2PU  - this call has been cancelled and will be postponed until next week. 

Apologies. 

**Misc.**

*   "We are addicted to P2PU" [](http://thepeople.p2pu.org/t/p2pu-site-down-urgent/548/4?u=vanessa)[http://thepeople.p2pu.org/t/p2pu-site-down-urgent/548/4?u=vanessa](http://thepeople.p2pu.org/t/p2pu-site-down-urgent/548/4?u=vanessa)

        *   I'm going to break the site more ofter - it's the only time we get good feedback

*   100% Edupunkery [](http://thepeople.p2pu.org/t/100-edupunkery/559)[http://thepeople.p2pu.org/t/100-edupunkery/559](http://thepeople.p2pu.org/t/100-edupunkery/559)
*   Recommended reading: Alex Hillman's Coworking Weekly: [](http://coworkingweekly.com/)[http://coworkingweekly.com/](http://coworkingweekly.com/)
*   "You might think on #3 that you should reduce the barrier to participation _so low_ that any anonymous users can just type words on the page and click "Submit". Trust me, you don't want this. You want a small, toddler-sized barrier -- having no barrier to registration at all means the bored and lazy people will inevitably overwhelm your site because they vastly outnumber everyone else. " --Jeff Atwood [](https://meta.discourse.org/t/how-to-build-a-community/13819/9)[https://meta.discourse.org/t/how-to-build-a-community/13819/9](https://meta.discourse.org/t/how-to-build-a-community/13819/9)

**Connecting Our Discourse Communities**

*   how to disseminate best practices amongst all?

        *   pre-seeding the community
    *   choosing categories
    *   subcategories and cohorts
    *   moderation privs
    *   tagging & polling plugins

*   categories sort of keep us separate
*   what if each discourse community we create had a meta that defaulted to p2pu's discourse? if someone cares enough to post to meta, aren't they an edutinkerer?