# Teach the web details

Sorry, ended up not keeping notes - or not in the right place

Forking

*    fork individual courses
*    aim for 1 click action in the future
*    1 - way forking for now - maybe later 2 way
*   investigate github submodules for individual courses
*   notify the MakeAPI when a course is forked (future)

 Discussion

*    use discourse - categories for courses and topics within categories for every piece of content

Signup

*   To discuss profiles & signon with moz
*   To get users set up for discussion & other make tools
*   To get get info about users - who signed up, etc.
*   Users will receive emails