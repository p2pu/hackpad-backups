# School of Open sync

*   we are now using p2pu.hackpad.com - pad.p2pu.org available read-only
*   When is the next round of SOO courses
*   What 