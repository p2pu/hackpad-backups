# Terms of use upgrade (to 4.0)

Domains that are affected:

p2pu.org

badges.p2pu.org

If you don't want to upgrade, let us know, so we can work with you to take your content down