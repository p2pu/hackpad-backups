# Hi, you are welcome and happy week, i Jesmion says thanks for all good you're doing, 

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!