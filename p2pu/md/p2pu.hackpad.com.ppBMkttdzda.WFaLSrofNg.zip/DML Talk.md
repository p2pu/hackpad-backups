# DML Talk

2:00-3:30 03/06/2014

[](http://dml2014.dmlhub.net/ai1ec_event/panel-otl-play-with-your-mooc-one-open-tool-3-different-flavors-of-learning/?instance_id=57)http://dml2014.dmlhub.net/ai1ec_event/panel-otl-play-with-your-mooc-one-open-tool-3-different-flavors-of-learning/?instance_id=57

Mech Mooc is the point of commonality and departure

Birth of the Mechanical MOOC: Steve Carson (20 mins)

*   OCW + mailing list tool (not a platform)
*   Became Mechanical MOOC
*   Use slides from OCW (10 slides)
*   Fussing with cohorts

Learning Creative Learning: Natalie (20 mins) 

*   Mechanical Mooc + other tools
*   Conversion story
*   Nuanced vision for learning online

#PWYM Play With Your Music: [Alex Ruthmann](/ep/profile/xb0845VCfyi) (20 mins)

*   Mechanical Mooc + affinity groups + other tools
*   Future: learner agency vis-a-vis time
*   Use the MOOC to sustain the community

Last slide

*   Point to reports
*   Link for these slides

Vanessa's Questions (15 mins)

How would you define "retention" in light of your experience?

How would you think about assessment within and amongst cohorts?

Future of Cohorts and Social Presence Around OER

Audience Questions (15 mins)

Notes

Slides to Vanessa March 1

Slides are there to support our arc

1st slide is structure of the course

Last slide outstanding questions

Steve's last presentation: [](http://presentations.ocwconsortium.org/ind2013_carson_the_mechanical_mooc_its_alive/)http://presentations.ocwconsortium.org/ind2013_carson_the_mechanical_mooc_its_alive/

7:42 minutes in (to check out the slides he used)