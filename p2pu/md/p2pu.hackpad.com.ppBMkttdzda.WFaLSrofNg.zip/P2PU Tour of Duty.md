# P2PU Tour of Duty

PS: An agreement between employer and employee to facilitate honest conversations. Employee doesn't feel like they have to be part of a family, can be honest about what they want, etc.

Good tool to use since we are becoming a more open org.

Tour of Duty does:

1.  Articulate a very specific goals
2.  Articulate benefits to the employer and employee

Normally between manager and employee, but between whole team for us.

Traditionally there is a clear separation between employee and employer, but we are all responsible for the org.

Network building aspect