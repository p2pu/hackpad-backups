# What an odds impression was the deletion of jesmion's studying profile at: p2pu.org/jesmion

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!