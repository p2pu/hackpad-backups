# Community Call - 23rd January

We're hanging out here - join us! 

[](https://plus.google.com/hangouts/_/hoaevent/AP36tYdmSEqPBrLPVJdTTAmR2CXIx2WtPqepcxDKaT3mfDkDsqATqw?authuser=1&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYdmSEqPBrLPVJdTTAmR2CXIx2WtPqepcxDKaT3mfDkDsqATqw?authuser=1&hl=en

**Attendees**

*   [Bekka Kahn](/ep/profile/BT4g65BvPRV)
*   [Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)
*   [Dirk Uys](/ep/profile/ppBMkttdzda)

*   New format: an experiment 

*   Would you take another P2PU course in the future?
*   ![](https://hackpad-attachments.s3.amazonaws.com/hackpad.com_RD9EEoLlayQ_p.80002_1390490385909_undefined)

**   How much of the courses did you complete?

![](https://hackpad-attachments.s3.amazonaws.com/hackpad.com_RD9EEoLlayQ_p.80002_1390490315058_undefined)

*   Dirk

        *   DLMOOC launched on Monday, had some small roadbumps, but Karen is mostly managing it all
    *   Data for June
    *   Data for Vanessa (see above)
    *   Experimenting with Jekyll (and github pages) for courses

**Agenda for discussion**

Topic for discussion: Companies without Managers (carried over from last week)

*   We had a discussion on [Discourse](http://thepeople.p2pu.org/t/excellent-article-about-working-without-managers/340/9)
*   What in the articles are things we like, but we are not currently doing
*   What can we change?

P2PU Reports 

*   Should we include personal by-lines for Lab reports (blog posts have authors)?
*   Promotion plan for these

P2PU comms

*   Mailing lists

        *   do they have a future? Role of mail inbox - still important to some
    *   mail alerts - for blog updates, for thepeopleupdates
    *   P2PU mailing lists - should we still use it at all? Is there a community of people who rely on email that we've lost by

*   Discourse:

        *   how we use it
    *   how others use it
    *   building community

Questions:

*   What part does the blog play?
*   support peoples preference vs simplicity in communications strategy

Next steps: BK to pull numbers from the mailing list: how many people used the list, and when and how. 