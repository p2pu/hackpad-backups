# Tech call 1 Jul 2015

*   Mandrill vs Sendgrid & djgrill
*   Docker deploy for p2pu-subscribe (and other services)
*