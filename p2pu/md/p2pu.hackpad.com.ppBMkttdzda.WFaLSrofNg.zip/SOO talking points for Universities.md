# SOO talking points for Universities

*   Add link to resource here.. 
*