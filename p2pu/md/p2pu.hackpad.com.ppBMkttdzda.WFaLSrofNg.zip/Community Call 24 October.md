# Community Call 24 October

**We're hanging out here  - join us!**

[](https://plus.google.com/hangouts/_/c454f477e045db50c1bb230710097eaa2c693667)https://plus.google.com/hangouts/_/c454f477e045db50c1bb230710097eaa2c693667

**Video playback: **

*   <u>Progress:</u>

        *   Music MOOC promotion (see below)
    *   Philipp spoke at Ithaka Conference in NYC (New venues for Lifelong Learning)
    *   Data Explorer Mission was this past weekend
    *   Moved info.p2pu.org to new hosting provider. Slowness should be resolved now.
    *   Set up thegovlabacademy.org and started building the site
    *   Grouped Python MOOC users
    *   DLMOOC signup page embedded in Wordpress site
    *   K-12 Online Educators talks is live: [](http://k12onlineconference.org/?p=1603&cpage=1#comment-243433)http://k12onlineconference.org/?p=1603&cpage=1#comment-243433

*   <u>Priorities (focus next week)</u>

        *   Strategy sign-off from board
    *   Strategy blog post
    *   Data Explorer Mission Write-up (learning from everything we do = new strategy)
    *   thegovlabacademy.org launch next Thursday
    *   Music MOOC grouping script - getting good data from Echonest, need to turn that into groups now
    *   Make HTML copy of archive.p2pu.org and host using github pages
    *   Send email to grouped users doing the Mechanical MOOC
    *   Update Tech Accounts doc to show where everything is running

*   <u>Problems</u>

        *   Vanessa found an apartment (she will stop being so frenetic)
    *   Internet has been extremely spotty in NYC, all over

*   <u>Major Achievements and Wins (new section)</u>

        *   [Philipp Schmidt](/ep/profile/Dc7zU8svumi) is a Red Sox fan now (8-1: take that and put it in your pipe and smoke it, Cardinals!!!)

*   <u>Process</u>

**Discussion**

Music MOOC Hustling by Vanessa (and others):

*

*   [](https://twitter.com/p2pu/status/393120292106547201)[https://twitter.com/p2pu/status/393120292106547201](https://twitter.com/p2pu/status/393120292106547201)

*

[](http://cl.ly/S7r4)http://cl.ly/S7r4

*

[](http://cl.ly/S0HS)http://cl.ly/S0HS

*   [](http://media.mit.edu/)[http://media.mit.edu/](http://media.mit.edu/)
*   2,000+ page views, 335 signups [](http://cl.ly/S7yr)[http://cl.ly/S7yr](http://cl.ly/S7yr)
*   99 sign-ups from NYC--so MHD and coworking/makerspace promotion has had somewhat of an impact