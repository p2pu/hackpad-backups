# Peer Review / Crowdfunding

Problem space:

*   lack of support and education around how to empower new entrepreneurs to crowdfund
*   product could be a course on how to crowd fund a project, or a tool for peer review or both
*   peer review that is scalable

Success would be:

- % of funded projects 

- % of people who fund each other’s projects (cross pollination)

indigogo

kickstarter

patreon

Questions:

Kauffman Founders School

Length of time / size of grants