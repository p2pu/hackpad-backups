# Notes from March 4 Community Call

Do you miss the space shuttle? What do NASA folks think of new players like SpaceX?

Pardon the pun, what do you see is the frontier in discovery of space for kids?

*   David: what's your fave project video (without or without you)
*   What are some of Davids fav tools in the shop?
*   Are there any specific areas you always tinker around?
*   What's the most difficult part of a project for you? Is it idea creation? Execution?
*    Are there any specific areas you always tinker around?
*   As a designer, are you thinking of each new bit discretely and independently or always in the context of how it would "fit" with larger kits or likely projects?

**aditi tolia**

12:23 PM

It wont let me unmute

old work laptop

sorry

Joey Wilson joined group chat.

Leo Saccomanno joined group chat.

**me**

12:25 PM

hey leo

**aditi tolia**

12:25 PM

atlanta

I work at the Museum of Design Atlanta

**me**

12:25 PM

awesome

**aditi tolia**

12:26 PM

Aditi, Atlanta, and my new fav is "I see fire"...Ed Sheeran

**me**

12:26 PM

can you post the track in the chat?

so we know the spelling

**Joey Wilson**

12:27 PM

Where is leo from?

**Leo Saccomanno**

12:27 PM

millencolin olympic

I'm from bariloche

**me**

12:28 PM

thanks leo

rad

and matthew we'll want yours too!

Question 2: When was the last time you were in awe of science? Was it a space museum? A fishing trip? Reading a psychology article? How could you use littleBits to re-create that experience? (Silently brainstorm in the chat for 5 mins)

I was inspired by cosmos recently

**Matthew Fisher**

12:30 PM

the last time I was in awe? hmmm

**Leo Saccomanno**

12:30 PM

I love watching the sky too

**Joey Wilson**

12:31 PM

I'ved recently read a book on raven intelligence and I'm wanting to build a raven/littlebits gizmo of some type

**me**

12:31 PM

very end of the black holes episode

[](https://www.youtube.com/watch?v=i2sF9gVnEVU)[https://www.youtube.com/watch?v=i2sF9gVnEVU](https://www.youtube.com/watch?v=i2sF9gVnEVU)

what is a raven joey?

Matthew you feel no awe???

**Leo Saccomanno**

12:31 PM

and it's always awe to me

**Joey Wilson**

12:31 PM

Its a bird. Like a big crow

**aditi tolia**

12:31 PM

26 pictures that will make you re-evalute your entire existence: [](http://www.buzzfeed.com/daves4/the-universe-is-scary#.rhvL8eG79)[http://www.buzzfeed.com/daves4/the-universe-is-scary#.rhvL8eG79](http://www.buzzfeed.com/daves4/the-universe-is-scary#.rhvL8eG79)

**Matthew Fisher**

12:32 PM

i went the maker faire in nyc. that was pretty cool.

Toni Smirniw joined group chat.

**Matthew Fisher**

12:32 PM

and mentally exhausting after about 8 minute

**Chloe Varelidi**

12:32 PM

Chloe: I am so inspired by the spacehack site... lately by these photos taken by astronauts of cities at night [](http://spacehack.org/project/cities-at-night)[http://spacehack.org/project/cities-at-night](http://spacehack.org/project/cities-at-night)

[](http://spacehack.org/project/cities-at-night)http://spacehack.org/project/cities-at-night

[](http://tinkererforlife.com/rubybits-11-earthquake-warning-and-monitoring-system/)http://tinkererforlife.com/rubybits-11-earthquake-warning-and-monitoring-system/

David Sharp: servo motors have the highest current of any of our bits

*

[](https://www.youtube.com/watch?v=dzpOBpz9LXQ)https://www.youtube.com/watch?v=dzpOBpz9LXQ

Learned about "lipstick chargers"

*

[](http://www.amazon.com/Chromo-2600mAh-Lipstick-External-Battery/dp/B0094JCZ5G)http://www.amazon.com/Chromo-2600mAh-Lipstick-External-Battery/dp/B0094JCZ5G

Solutions to random

**   Does david have a fav laser cutter?
*   Great everyone!
*   **Toni S**yes or hurt the pieces
*   **Arjun S**SHOES
*   **Joey W**Shoes screwed into wood works pretty well
*   **Toni S**are shoes seperate...I have 2 kits but there are no shoes
*   **Gayle R**@Joey W .. .. let me know if you want someone to beta test out your gear cheat sheet
*   **Arjun S**some kits have shows (Smart Home)
*   **Arjun S**but we sell them online
*   **Joey W**Will do @gayle. Send me email maybe?
*   **Gayle R**OK. How do I send u my email?
*   **Joey W**send it to [joeymail@mac.com](mailto:joeymail@mac.com)
*   **Nick W**Thanks @David & @Chloe
*   **Gayle R**Okie Dokie
*   **Vanessa G**Red: my google hangout is crashing :(
*   **Tom S**thank you for awesome call. see you next week!
*   **Vanessa G**Green: David Sharp is awesome
*   **Heidi C**@Vanessa - can we rewatch the beginning of this?
*   **Tom S**green: cool to see what everybody else is doing
*   **Arjun S**green: david's beard
*   **Gayle R**green loving the community
*   **Tom S**red: seeing myself on video
*   **Heidi C**Red: Phone time - 12 noon is preschoolers lunch. I wish we had a earlier one (9 am)
*   **Vanessa G**@heidi yes, totally
*   **Vanessa G**we will post the video in just a sec
*   **Vanessa G**Now it should be up
*   **Joey W**@gayle hit the afterparty room
*   **Gayle R**Good nite all [2:10am here} gotta get up for school @ 5:15am
*   **Chloe V**Goodnight @Gayle <3 thank you so much for joining
*   **Joey W**Or drop me an email and I'll get you some stuff
*   **Toni S**yellow for me personally, can't figure out how to make things work in chat or uploading....am a work in progress and will practice see you next week
*   **Gayle R**@Joey must got to get 3 hours sleep before I go t school and teach
*   **Vanessa G**Thank you @gayle!
*   **Joey W**no worries @gayle
*   **Gayle R**It's been so fuuuunnnnnn
*   **Chloe V**Don't forget to share with us feedback about the course so we can improve it :)
*   **Gayle R**@Joey I will email you
*   **Vanessa G**@toni i am making a tutorial also that may hep
*   **Chloe V**red: what doesn't work, yellow: what is confusing, green: what you really like!
*   **Chloe V**COLOWHEEL
*   **Chloe V**COLORWHEEL
*   **Toni S**Yeah @ Vanessa!
*   **Leo S**green: bitster map
*   **Vanessa G**awww we <3 the map also @leo

*

[](https://www.youtube.com/watch?v=Q6goNzXrmFs&feature=youtu.be)https://www.youtube.com/watch?v=Q6goNzXrmFs&feature=youtu.be

**Manuel Avendaño**

7:53 PM

[](http://youtu.be/Q6goNzXrmFs)[http://youtu.be/Q6goNzXrmFs](http://youtu.be/Q6goNzXrmFs)

**me**

7:55 PM

oh man

this music

RICH HARVESTS FTW

**Ginger Butcher**

7:55 PM

Oh, science needs Sagan back

OMG space channel iFFT [](https://ifttt.com/space)https://ifttt.com/space