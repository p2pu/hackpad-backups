# P2PU Badge Demo

**PLEASE JOIN US HERE ----->**

Hangout: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYcGUq_oV6fmIQNawfmyV03jX2-WGyVDD98Wr6oG8QqBT_5rOg?authuser=0&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYcGUq_oV6fmIQNawfmyV03jX2-WGyVDD98Wr6oG8QqBT_5rOg?authuser=0&hl=en

Attendees:

*   Vanessa
*   Chris
*   Jade
*   Sunny

What Do You Know About P2PU Badges?

*   Vanessa is a PowerLaugher™

        *   ha.

*   Is it a platform for anyone to use?
*   Open source
*

What Do You Want to Know about P2PU Badges?

*   Put yer queries here
*   What's success for P2PU platform? 6 months, 2 years?
*   Use cases: 3 badges for 50 people?
*   Can P2PU badges be white-labeled?

Resources:

*   [](http://badges.p2pu.org/en/)http://badges.p2pu.org/en/
*   [](http://badges.p2pu.org/en/about)http://badges.p2pu.org/en/about
*   [](http://badges.p2pu.org/en/search?q)http://badges.p2pu.org/en/search?q
*   Design principles and user personas: [](http://www.slideshare.net/VanessaGennarelli/badge-spec-for-p2pu)http://www.slideshare.net/VanessaGennarelli/badge-spec-for-p2pu
*   Sample badge: [](http://badges.p2pu.org/en/badge/view/434/)http://badges.p2pu.org/en/badge/view/434/
*   [](http://badges.p2pu.org/en/search?q=alexruthman)http://badges.p2pu.org/en/search?q=alexruthman
*   [](http://thepeople.p2pu.org/t/feedback-on-badges-p2pu-org/113/33)http://thepeople.p2pu.org/t/feedback-on-badges-p2pu-org/113/33
*   [](http://badges.p2pu.org/en/dashboard/webmaker/badges)http://badges.p2pu.org/en/dashboard/webmaker/badges

Notes:

*   Create a badge and issue a badge