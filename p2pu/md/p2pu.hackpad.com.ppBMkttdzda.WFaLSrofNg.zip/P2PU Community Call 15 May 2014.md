# P2PU Community Call 15 May 2014

Attendees:

*   [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)
*   [Dirk Uys](/ep/profile/ppBMkttdzda)
*   [Erika Pogorelc](/ep/profile/oTNkHa0lFrI) 
*   [Philipp Schmidt](/ep/profile/Dc7zU8svumi)
*   Natalie Green
*   Nathan (Khan Academy)
*   Carolina
*   Jane

Agenda: