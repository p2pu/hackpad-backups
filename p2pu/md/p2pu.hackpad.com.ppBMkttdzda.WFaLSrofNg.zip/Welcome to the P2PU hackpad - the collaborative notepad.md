# **Welcome to the P2PU hackpad - the collaborative notepad**

We are experimenting with this as a replacement for etherpad. We love etherpad, but maintaining the server became a headache. A big headache for a tiny organization. 

Some pointers to get you started:

*   Create pads (by clicking the "**+**" button above) and **invite people** to them.  Once they arrive, you can **edit in real-time**.  Changes made when the other people aren't around are **emailed to everyone.**

*   _type here to try it out _<u> </u>[Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)  [Dirk Uys](/ep/profile/ppBMkttdzda) 'sup?
*   Hey [niels](/ep/profile/nVwVHSXvnsI) !! You should come and check out [](http://community.p2pu.org)http://community.p2pu.org

<u>Hi, </u>[Philipp Schmidt](/ep/profile/Dc7zU8svumi) 

I found this: [](https://hackpad.com/How-to-use-Hackpad-mlZvEsJykI5)https://hackpad.com/How-to-use-Hackpad-mlZvEsJykI5

*   You can create **todo items** like these by clicking on the checkbox button above.

*   To access your pads on the go, just open this website on your **iPhone** or **Android.**

Have fun!