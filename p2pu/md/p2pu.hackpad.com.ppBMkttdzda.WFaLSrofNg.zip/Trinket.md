# Trinket

Some thoughts on quickly playing with Trinket

*   Allows creating 2 level hierarchy of content
*   Uses markdown
*   Embed videos using markdown image links
*   Doesn't allow HTML elements
*   Nice side-by-side editor
*   Allows adding runnable Python code
*   2014-03-05 - interface still fairly basic
*   actually, not worth evaluating right now - they need more time to fix obvious problems and add functionality