# Invent Anything Weekly Hangout

## Week 5

[format]

*   10 min share: state of the community--**CHLOE**

        *   What did you notice was going on this week?
    *   Biiiig thank them- because they are the superstars
    *   Including their feedback (keeping things simple and straightfoward)

*   20 minutes: Hands-on meet and work--**VANESSA**

        *   Meet + work: look through the Welcome / Introduce yourself people

                *   Follow 3-5 of them and their posts, reply to them
        *   Those are your peeps--and you'll get more! (With 1,700 there will be lots)

        *   What is one trick about discourse you learned that you want to share
    *   Vanessa: bob and weave

1.   read through FAQs?  [](http://littlebits.cc/hello-invent-anything)http://littlebits.cc/hello-invent-anything

*   How should we celebrate a success?
*   How can we connect new people to each other?
*   When and how should we share that we've posted projects? 

3.  bitstar status; unlocked 20% discount 

Takeaways:

*   Design challenges should be something new OR remix a project below
*   Community Call: schedule a weekly critique 
*   MakerCamp format: 
*   Add information about guests who are coming

## Week 4

[format]

20 mins  [ Intro ]

20 mins [ Activity 1 ]

20 mins [ Activity 2 ]

**Intro: **

*   Icebreaker: best birthday everrrrr

        *   Memorable--thematic connections (superheroes, costume parties, playful, dancing in rain)
    *   Physical: dancing, roller disco
    *   Playful: costumes
    *   Wonder: horse with LED lights on it
    *   Acumen courses--> human-centered design brunches
    *   Meta: group intentions, flexbile
    *   Anmol went to 30 hackathons-->hackathon like carnival
    *   Celebrating something shared amongst people
    *   We draw the plates on the tablecloth etc etc. It was a huge mess afterwards.. but a lot of fun for sure;)

*   Time for questions

**Chloe Varelidi**

12:05 PM

[](http://en.wikipedia.org/wiki/Dazzler)[http://en.wikipedia.org/wiki/Dazzler](http://en.wikipedia.org/wiki/Dazzler)

we are sharing favorite 

**Alice Lin**

12:13 PM

[](http://plusacumen.org/courses/)[http://plusacumen.org/courses/](http://plusacumen.org/courses/)

**me**

12:01 PM

[](http://www.ted.com/talks/susan_cain_the_power_of_introverts?language=en)[http://www.ted.com/talks/susan_cain_the_power_of_introverts?language=en](http://www.ted.com/talks/susan_cain_the_power_of_introverts?language=en)

hi peter!

Erin

[](http://edcamp.org/)http://edcamp.org/

**Anmol Agrawal**

12:53 PM

[](https://www.ted.com/participate/ted-prize/prize-winning-wishes/school-in-the-cloud-sugata-mitra)[https://www.ted.com/participate/ted-prize/prize-winning-wishes/school-in-the-cloud-sugata-mitra](https://www.ted.com/participate/ted-prize/prize-winning-wishes/school-in-the-cloud-sugata-mitra)

Picking a focus first

context before putting in a link

helping people understand

Miland: 200-600

workshop with school teachers 

followed up by access to pro library for week

and let them teach/take workshops for kids

Anmol: Advice: balance serendipity and structure

Chloe: pairing a designer with a teacher, work backwards, don't give them bits before you explain to them what you want to do, short breaks

Valetina: flexibility with time

Anmol: move power from instructors to learners

Vanessa: 

Alice: fishbowl, kids observe peers as they learn 

**Valentina Chinnici**

12:54 PM

[](https://www.edutopia.org/pdfs/coop_math_bowman/bowman_fishbowl_method.pdf)[https://www.edutopia.org/pdfs/coop_math_bowman/bowman_fishbowl_method.pdf](https://www.edutopia.org/pdfs/coop_math_bowman/bowman_fishbowl_method.pdf)

**Anmol Agrawal**

12:54 PM

-Mr.Cobb, movie Inception

**Erin Mulcahy**

12:55 PM

[](https://s3.amazonaws.com/littleBits_pdfs/littleBits_IndividualModulesCards.pdf)<u>[https://s3.amazonaws.com/littleBits_pdfs/littleBits_IndividualModulesCards.pdf](https://s3.amazonaws.com/littleBits_pdfs/littleBits_IndividualModulesCards.pdf)</u>

**Chloe Varelidi**

12:55 PM

great resource erin! we can include it in the event guides

**Activity 1: How to Use Rooms**

**Activity 2: Hack the Event Guides:**

*   Choose the Make-a-thon, Workshop or Meetup room-->closest to the event that you would throw
*   Rooms are already set up: [](https://unhangout.media.mit.edu/event/98)https://unhangout.media.mit.edu/event/98
*   Cruise through the event guide 
*   Note 2 reds, 2 yellows 2 greens
*   Come back and present the guide and your recommendations to the group

Make-a-thon: [](https://chloe-littlebits.makes.org/thimble/ODE5NTkzNDcy/how-to-host-a-littlebits-make-a-thon)https://chloe-littlebits.makes.org/thimble/ODE5NTkzNDcy/how-to-host-a-littlebits-make-a-thon

Workshop: [](https://chloe-littlebits.makes.org/thimble/MTg5MjgxMTAwOA==/how-to-host-a-littlebits-workshop)https://chloe-littlebits.makes.org/thimble/MTg5MjgxMTAwOA==/how-to-host-a-littlebits-workshop

Meetup Friends and Family: [](https://chloe-littlebits.makes.org/thimble/LTEzMjg3NDIxNDQ=/how-to-host-a-littlebits-meetup)https://chloe-littlebits.makes.org/thimble/LTEzMjg3NDIxNDQ=/how-to-host-a-littlebits-meetup

**Activity 3: Your Dream Event**

*   Each person presents an event that you might hold locally

        *   And then receives 2-3 suggestions from the roundtable

*   Next steps for you: something you have and something you need
*   Share your event on Discourse

** Homework:**

*   record a 15 second video of what you think invent anything is?

        *   Name, where I'm from and I invent "Education" in your mother language
    *   If they are not from the US, to say it in their own language
    *   What they love so far about the course: "What I love about the course is"

*   name, where you are from, and why you love / joined inventanything
*   Read "Design Thinking for Educators" [](http://www.designthinkingforeducators.com/design-examples/)http://www.designthinkingforeducators.com/design-examples/

** Small groups**

## Week 3

[format]

20 mins  [ Intro ]

20 mins [ Activity 1 ]

20 mins [ Activity 2 ]

**Intro**

*   Share your name and favorite monster (@vanessa's is chuthlu)
*   Share a project you've been working on this week that you want some help with
*   Share something you've noticed from the forums you want to mention
*   Allot some time for "how things work" questions / silly questions

**Activity 1: Privacy + IoT**

*   [](http://discuss.littlebits.cc/t/1-2-discuss-big-data-privacy-the-other-side-of-iot/17277)http://discuss.littlebits.cc/t/1-2-discuss-big-data-privacy-the-other-side-of-iot/17277
*   When have you been creeped out by a machine / product knowing something about you?
*   What kind of challenge would help someone understand how they felt about privacy / iot?
*   What other resources are your favorites when struggling through these issues? Post them to the discourse thread

If you are entering this room, you are providing us with all this information.

If you agree to that we, will agree to all of your data records forever

Interesting as a perspective to see what you are sharing-->no one reads end user license agreements

A magician that could share all the data around 

Morgan Spurlock, science-->trying to replace writers with computers

Murdon Spurlock-->wrote his bio by how long he wanted it

Have people do a bio of someone else written by a computer

Chloe--.use an ifft to mashup data about you on the web

**JackANDJude**

12:25 PM

You can get Google notifications for key words, and you can probably use your own name as a key word.

**Valentina Chinnici**

12:26 PM

Here you are the ad  [](https://www.youtube.com/watch?v=OBEeTiNAlGM)[https://www.youtube.com/watch?v=OBEeTiNAlGM](https://www.youtube.com/watch?v=OBEeTiNAlGM)

Joey--its like your purse or wallet are lost or stolen

emotional impact of the violation-->lost or stolen

take your purse or wallet, dump it out 

what are you comfortable with everyone knowing and not knowing

Joey--this american life episodes

Hack the cloud--

the more connected the world is, the more insecure it is

easy to steal, not hard to track every one

Wit.ai

[](http://youtu.be/_m-fmDP3osU?list=PLIGv8LbBI3iQ8oEh6wgVdHluz3RKqXbv5)[http://youtu.be/_m-fmDP3osU?list=PLIGv8LbBI3iQ8oEh6wgVdHluz3RKqXbv5](http://youtu.be/_m-fmDP3osU?list=PLIGv8LbBI3iQ8oEh6wgVdHluz3RKqXbv5)

**Anmol Agrawal**

1:05 PM

[](https://www.youtube.com/playlist?list=PLIGv8LbBI3iQ8oEh6wgVdHluz3RKqXbv5)<u>[https://www.youtube.com/playlist?list=PLIGv8LbBI3iQ8oEh6wgVdHluz3RKqXbv5](https://www.youtube.com/playlist?list=PLIGv8LbBI3iQ8oEh6wgVdHluz3RKqXbv5)</u>

Controlling littlebits LED

**Feedback on event guides**

*   [](https://chloe-littlebits.makes.org/thimble/MTg5MjgxMTAwOA==/how-to-host-a-littlebits-workshop)https://chloe-littlebits.makes.org/thimble/MTg5MjgxMTAwOA==/how-to-host-a-littlebits-workshop
*

**Metacognitive timez: Red / Yellow / Green InventAnything**

*   In breakout rooms with folks of 2-3 share the reds / yellows / greens about Invent Anything

## Week 2

[format]

10 mins  [ Intro ]

15 mins [ Activity 1 ]

20 mins [Activity 2a + 2b]

15 mins [ Activity 3 ]

## Intro: 

*   Name and fight song
*   If there was something littleBits / Invent Anything that you struggled with this week? (ask on the call if anyone can fix)
*   Surprise announcement: 

## Activity 1:  How to Attribute?

*   [](http://discuss.littlebits.cc/t/1-2-discuss-remixing-empathy/17947)http://discuss.littlebits.cc/t/1-2-discuss-remixing-empathy/17947
*   When has someone attributed you that made you feel warm + fuzzy inside?
*   Remixing is a way to build relationships--have you ever reached out to someone who inspired you?
*   What is the right way to attribute?
*   How should we encourage others to attribute work in InventFest?

## Activity 2: Design a Design Challenge

1.  List 3 things you are good at
2.  Pick one, pop into one of the separate rooms (Synth, Science, etc) and meetup with another bitstar

*   how does this work? ^^
*

Good projects:

1.  Find a "good" project on MakerHub
2.  Describe what makes it "good"? What steps did they take?
3.  Share out: [Post a list in Hackpad or in Discourse with attribution from particular bitstars]

## Activity 3: Add a Resource

On Discourse:

*   Choose a track
*   Add a resource (an article, a youtube video)
*   Comment on someone else's thread
*   Upload a photo and change your digest settings

## Introduction

VG: Brief intro + housekeeping. Un-hangout explanation, mute yourself, how to ask questions etc.

Name

Location

What has been your favorite experience from your organization

Which bit are you?

Why do you think you've been asked here?

## Activity 1: We're Here to Solve Your Problem

Activity: what do you need help with in building your programming?

Make a list on Google Unhangout of 2-3 things

Share out with the group why / paint points

## Goals of the Chaptes program 

*   A *free* five week-long online making festival with peers
*   A training to help you level up your maker skills
*   Where you learn how to run events and mentor others to [#InventAnything](https://p2pu.hackpad.com/ep/search/?q=%23InventAnything&via=uCXMkm4VGzE) with littleBits
*   February 18th. launch
*   Everything is in beta (we want your feedback right meow)
*   15% discount for this group
*   Free swag

In  parallel we are also in the process of launching a chapters program,  with selected orgs around the world, some of you today are in that  group.

[](http://discuss.littlebits.cc/categories)http://discuss.littlebits.cc/categories

## How this Will Work
<undefined><li>6 tents or tracks</li></undefined>

*   Introduction
*   Synth
*   Art & Design
*   Science
*   IoT
*   Hardware
<undefined><li>4 pieces each week</li></undefined>

*   Make a Project
*   Team Up with Others
*   Discuss
*   Hangout

**Tools:**

*   Unhangout
*   Event guides
*   Discourse
*   Hashtag [#inventanything](https://p2pu.hackpad.com/ep/search/?q=%23inventanything&via=uCXMkm4VGzE)

## Where we need your help

1.  Testing the design challenges and platforms
2.  Posting your projects to MakerHub
3.  Adding resources
4.  Being a resource for others

## Activity 2: What traits do good communities have?

*   What are your favorite communities and why?
*   What behaviors should we model on the discourse?
*   Add to our code of conduct

## Questions and Answers?