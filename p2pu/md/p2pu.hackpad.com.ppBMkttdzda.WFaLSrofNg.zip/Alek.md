# Alek 

Call April 11, 2014

Erasmus+ funds 'strategic partnerships'

Uni Gutenberg

Glasgow catelonian uni

??

small consultancy

And CC poland

proposal inclused much on increasing OER use

repositories, research, etc.  Bit that interests us is training.  We want to focus on online training - both facilitated and not. Would reuse much content but be much new content.  Re technology part we're vague and would be looking for help/do it.  Was thinking SoO - we know it well.  Was thinking 

We and open uni would be responsible for content, you for tech.

Was thinking of you as platform 

We would be creating course for fall 2015 (northern) - do the work mid-2015

P2PU as subcontractor, not as consortium partner.

Size and length of course? We don't know yet.  Thinking paths 2 months (8 wks).  Don' tknow no. of participants - thinking 500s.  Don't want 1000s.  [haven't thought this through in detail, felt hundreds was enough of a commitment.]  Would you consider 1000s a failure? No.

Language? Want it bilingual.  Don't care how.  English and Polish.  Could be interesting questions there about relative experience.

Level of facilitation?  don't know yet.  Planning some, probably people from Open University with experience on teaching.  CC Poland not academic and experience re teaching 

 Whose target audience?  Confusing - Program basically requires targetting K-12, higher ed, adult learning, informal youth learning.  Will def be educators.  Will be a training course.

Timeframe?  Deadline is 28 April, we'll aim slightly earlier.  Working intensively on it now.  Expect grants will be awarded another 6mths down the track, program will start in 2015, Jan, run to mid-2016.  This part of the project (training) is 8 mths - 4mths design, 4mths delivery.

 