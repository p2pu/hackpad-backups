# Relevant Research

Craxton, R. (2014). "The Role of Interactivity in Student Satisfaction and Persistence 

in Online Learning." MERLOT Journal of Online Learning and Teaching Vol. 10, No. 2, June 2014 [](http://jolt.merlot.org/vol10no2/croxton_0614.pdf)http://jolt.merlot.org/vol10no2/croxton_0614.pdf