# Community Call - 9 January 2014

**Attendees**

*   Bekka
*   June
*   Erika
*   Dirk

**Agenda for discussion**

Org: Community call removed from calendar?

We're hanging out here - join us!: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYcZQ6UJ2egvZO6jc0KPVgC8147xfa-wTL_EMItEVLL4CNl8Ww?authuser=1&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYcZQ6UJ2egvZO6jc0KPVgC8147xfa-wTL_EMItEVLL4CNl8Ww?authuser=1&hl=en

*   New format: an experiment for last call of the year! 

*   Staff update: what's keeping you busy (10 min)

        *   Dirk: a bit of blog stuff, some sys admin stuff, just picking things up and getting going again
    *   Erika: looking into how to make reports easier for Bekka! Looking at Jekyll - but template might not be that easy to transfer over.

    *   Working on LCL report together with Bekka (it already looks great :))

    *   June: introduced a 2 year old to Christmas. 

                *   In terms of data-sharing we had loads of grand plans, whitelist, licensing, hosting etc.
        *   Database tables will be shared to CSV files for sharing
        *   Sarah is working on some more
        *   Would be ideal to release them in January - a set of zipped files and a ReadMe file

                        *   documenting how MOOCS were run for those which and multiple iterations would be useful for providing context for the data and those who might want to analyse the data

*   WIP board:  new Trello board: [](https://trello.com/b/8NlzI2nG/wip)[https://trello.com/b/8NlzI2nG/wip](https://trello.com/b/8NlzI2nG/wip)
*   Feedback:  

**Progress**

*

**Priorities**

**Problems**

**Process**

**Ideas**