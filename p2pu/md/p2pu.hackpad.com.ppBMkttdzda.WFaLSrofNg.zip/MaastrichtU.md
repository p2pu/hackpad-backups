# MaastrichtU

People

*   Dirk
*   Bekka
*   Jeroen
*   Jeroen
*   Odin
*   Daniella

Introductions

About P2PU

MOOCs, we're sceptics.

Mechanical MOOC (Gentle introduction to Python)

Play With Your Music (grouping people by musical taste - using data from echonest API)

Openness of the MOOCS - it's always open for signup, as soon as critical mass is reached, the course is triggered, and it will run again. 

Maastricht is a problem based university

students work in groups of 10-12

relative few courses

Don't like a typical MOOC model

Communities and working in small groups is more effective

MOOC: student will work in small groups on a series of tasks/problems

students will have choice of tasks, need to do 6 to complete the course

compose students on the base of their interests. expecting dropouts. groups are formed after each task. Regroup to keep active groups.

Async & sync groupwork. Students asked if they want to work synchronous or asynchronous? Want to develop a MOOC that is always open.

Peer review after tasks

Questions:

What is the general topic?

*   Problem based learning

Will everything be open?

Timeframe

*   March 2015

Should consider going mobile?