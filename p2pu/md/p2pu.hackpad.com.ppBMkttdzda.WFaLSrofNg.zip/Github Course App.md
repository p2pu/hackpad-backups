# Github Course App

Forking

*   Natural git workflow
*   Base repository keeps track of forks
*   Github only allows 1 fork of a repository per user
*   Need to use command line or github app to get the latest code from the repository that you forked
*   Not intuitive to non git users what you are doing

Creating repositories under an organization

*   courses can be hosted by Github under 1 domain
*   one place where we see all the courses
*   Cannot be forks
*   Repository and team needs to be created server side
*   If all repositories is hosted under a single domain we need to ensure that there aren't malware or spam

Ideas

*   Ability to create from different templates (for i18n)
*   Fork repositories into organization to host under a single domain

Questions

*   What makes this different from using WP for a course?