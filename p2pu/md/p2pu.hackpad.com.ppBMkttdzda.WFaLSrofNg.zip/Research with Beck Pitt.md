# Research with [Beck Pitt](/ep/profile/mfpQdO1ZS47)

Google hangout: [](https://plus.google.com/hangouts/_/calendar/dmFuZXNzYUBwMnB1Lm9yZw.oj38heoofoovnehsd4ir01kg94)https://plus.google.com/hangouts/_/calendar/dmFuZXNzYUBwMnB1Lm9yZw.oj38heoofoovnehsd4ir01kg94

PWYM Research: [PWYM Research](/ZhKViyvAWGx)

Writing for Change plan: [Writing for Change](/fb4QHG43e1Q)

Agenda:

*   Walk through project plan for writing for change

        *   Tools we're planning to use

                *   Discourse for community communication
        *   Static HTML for course content

*   Decide research instruments needed

        *   Pre-survey
    *   Post-survey
    *   Engagement metrics / measurement
    *   Motivation for participation
    *   Sense of community

*   [Dirk Uys](/ep/profile/ppBMkttdzda) to design / implement metrics

Next steps:

*   [Beck Pitt](/ep/profile/mfpQdO1ZS47) to read to proposal, consult colleagues, sketch out ideas for research instruments
*   Beck has a conference-->include her in curriculum design
*   End of next week: Friday the 13th

Draft and brainstorm of research ideas for Writing for Change sent to Vanessa and Dirk on 06/13/14. Further discussion pending. 