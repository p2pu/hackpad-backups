# Open Research Course: Feedback and Suggestions 

We welcome feedback and suggestions on our P2PU Open Research course ([](https://p2pu.org/he/courses/2377/open-research/))https://p2pu.org/he/courses/2377/open-research/) so that we can improve and develop the course for its second iteration in early 2015 and a non-facilitated, standalone version. Let us know your thoughts and ideas below; we'll be reviewing these during December 2014. 

Many thanks, Beck (on behalf of the Open Research course team) 