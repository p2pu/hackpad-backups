# Hewlett Meeting Agenda

Questions for TJ

*   Which issues are you passionate about?
*   What objectives do you have for your tenure?
*   What opportunities do you see in this space?
*   How do you view P2PU? What is P2PU known for? 

Interim Report

*   Questions

Future / problem areas

*   Data collection (distributed dashboard)
*   Marketing support (need to build critical mass for projects to work)
*   Organizational change