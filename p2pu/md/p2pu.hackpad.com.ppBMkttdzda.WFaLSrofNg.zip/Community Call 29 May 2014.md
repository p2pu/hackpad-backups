# Community Call 29 May 2014

Event link: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYcTqGhAEkQCRsJm4TFICs70Bk957UaGo1ujphpw79G_C1KDow)https://plus.google.com/hangouts/_/hoaevent/AP36tYcTqGhAEkQCRsJm4TFICs70Bk957UaGo1ujphpw79G_C1KDow

Attendees:

*   [Dirk Uys](/ep/profile/ppBMkttdzda) 
*   [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD) 
*   [Philipp Schmidt](/ep/profile/Dc7zU8svumi) 
*   [Alex Ruthmann](/ep/profile/xb0845VCfyi) 
*   [Bekka Kahn](/ep/profile/BT4g65BvPRV) 
*   Andrew Sliwinski (DIY.org)

Agenda

*   Interview with Andrew

Questions:

*