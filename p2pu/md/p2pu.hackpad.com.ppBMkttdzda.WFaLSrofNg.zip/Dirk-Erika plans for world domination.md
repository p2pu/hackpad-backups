# Dirk/Erika plans for world domination

**11.4.2004**

*   SoO project

        *   homepage - [](http://schoolofopen.p2pu.org)http://schoolofopen.p2pu.org

                *   Leave it as is... until Jane comes back to us

        *   DU to send email to Jane

*   Moving forward with Topnav 

        *   first step: making an HTML version of a mockup
    *   next step: speaking with Carl about reshuffling some stuff to footer for example
    *   have discussion with the team about the topnav content
    *   release nice new shiny top navigation