# P2PU Community Call - 27 March 2014

We're hanging out here:   [](https://plus.google.com/hangouts/_/hoaevent/AP36tYdxElx9z07fQK7Lh-Y0tSh3mIcwR8YS2ZlxSVVVIzKdRMmVJA?authuser=1&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYdxElx9z07fQK7Lh-Y0tSh3mIcwR8YS2ZlxSVVVIzKdRMmVJA?authuser=1&hl=en  join us!

Attendees

[Bekka Kahn](/ep/profile/BT4g65BvPRV)

[Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)

**Discussion:**

Guest speaker: Beck Pitt (Open University, OER Research hub) discussing research conducted with School of Open

Pre call prep: please read blog posts [Part 1](http://oerresearchhub.org/2014/03/10/school-of-open-research-findings-part-i/)  and [Part II](http://oerresearchhub.org/2014/03/14/school-of-open-research-findings-part-ii/)

*

If you have any questions for Beck, add them here:

Beck talks about what it means to be open and how that affects how/what people learn. 

BK: Questions about use of open licences as a motivating factor

Questions about badges and impact +1

VMG: Badges not motivating--but are they relevant? Who do people show badges to?

PS: What aspect of "open" most differentiated the SOO courses from closed online learning? What was the effect? 

VMG: Can you say a bit about engagement / interaction? (This Q might be more for Open Science course)