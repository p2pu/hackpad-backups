# ExplOERer

**Translations**

Should we create a single DNS for all courses with a /en /sv and /pl subdirectory for each

Use single GitHub repository

*   simple deploy
*   GitHub can host course content for a longer time
*   team needs to work on a single repository

Should we create a separate DNS for each course?

*   $20 dollar for 2 extra DNSs