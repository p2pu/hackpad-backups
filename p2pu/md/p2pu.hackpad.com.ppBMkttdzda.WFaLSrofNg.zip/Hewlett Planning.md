# Hewlett Planning

Background Material:

Letter: [](http://annualletter.hewlett.org/)http://annualletter.hewlett.org/

Videos: 

*   [](http://www.hewlett.org/programs/education/deeper-learning/what-deeper-learning)http://www.hewlett.org/programs/education/deeper-learning/what-deeper-learning
*   [](http://www.hewlett.org/programs/education/deeper-learning/why-deeper-learning-important)http://www.hewlett.org/programs/education/deeper-learning/why-deeper-learning-important
*   [](http://www.hewlett.org/programs/education/deeper-learning/deeper-learning-possible)http://www.hewlett.org/programs/education/deeper-learning/deeper-learning-possible
*   [](http://www.hewlett.org/programs/education/deeper-learning/what-hewlett-foundations-role)http://www.hewlett.org/programs/education/deeper-learning/what-hewlett-foundations-role

Questions: 

*   are we late to the party with being asked to pitch a letter? 
*   focus on K-12?
*   What does Hewlett see that we can give them?
*   Deeper learning is more assessment / results for teachers / capacity building

1.  Previous grants: 200k in 2013, 40k in 2014
2.  Drafting and delivery

meeting weds or friday

a few ideas

deeper learning webinar

BK: Do we hit the 1% and not the 99%?

*   where does Hewlett see the value in what we do? What's their value proposition for funding us?
*