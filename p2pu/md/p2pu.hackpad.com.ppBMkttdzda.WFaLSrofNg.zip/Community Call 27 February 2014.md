# Community Call 27 February 2014

([how to start the call here](https://p2pu.hackpad.com/Starting-a-Community-Call-siWKeO4pPY7))

We're hanging out here: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYf-HKDhWSujUUMHvBkv716JgeFvuGF6lWbUpHFZ4_neCutomQ?authuser=0&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYf-HKDhWSujUUMHvBkv716JgeFvuGF6lWbUpHFZ4_neCutomQ?authuser=0&hl=en

 - join us! 

**Attendees**

*   [Dirk Uys](/ep/profile/ppBMkttdzda) 
*   [Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)
*   [Erika Pogorelc](/ep/profile/oTNkHa0lFrI) 

**The P2PU Weekly Roundup - see **[Project Pad](https://p2pu.hackpad.com/P2PU-Project-Call-5QyILCrcDdV)

*   UPDATE: New format for this call: P2PU now doing a 'project call' at 10am EST Thursdays (1hr before this call) to report on work in progress and discuss specific projects

**Discussion**

*   Website changes  - see [Website changes](https://p2pu.hackpad.com/b0IpkN3UgQu) hackpad and email thread

Did we say that we also want to talk about the "Course about running a course"?