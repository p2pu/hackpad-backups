# Professional Development + Badges

July 1, 2014

[](https://unhangout.media.mit.edu/h/p2pu)https://unhangout.media.mit.edu/h/p2pu

Attendees

*   Erin Knight
*   [Erika Pogorelc](/ep/profile/HgL1VSf8fsX)
*   [Philipp Schmidt](/ep/profile/Dc7zU8svumi)
*   [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)

Current projects in this space

Erin to describe the need/opportunity (PD badges)

Interested groups?

Potential funding sources

**Erin Knight:**

Educator badges working group -- 150 of them

Digital promise--formal teacher badging pathway-->they have another community that has another 150 organizations

There's a lot of demand and hunger

Organizations bring specific needs / demands (clear use cases)

PD defined broadly - not creating another "accountability" system

Teachers are empowered to express who they are as teachers

BA working group to provide taxonomy / links between badge systems

Common definitions of badge types (certification badge, peer badge ...)

Technology platforms: badge.us / credly

Lots of people working analog right now

[Philipp Schmidt](/ep/profile/Dc7zU8svumi)

*   Are people looking for a wordpress-type solution?

        *   People dont want to be building something on their own servers? 
    *   Digital promise is exception--they have very specific needs

*   Need (and revenue oppt): Tech customization and badge design

*   [Vanessa Gennarelli](/ep/profile/Cw53PwvRgVD)

*   Sets of badges / on offer for other organizations to adopt
*   Roster associated with an organization or class
*   That was the original vision for Webmaker badges
*   Folks are making money from the consulting-->learning design, visual design, tech customization
*   How does this bump up against moocs?

Next steps:

[Erika Pogorelc](/ep/profile/oTNkHa0lFrI) joins working group

Erin makes recommendations about potential folks

[Erika Pogorelc](/ep/profile/oTNkHa0lFrI) downloads wordpress plugin (Badge OS)