# Hi Dirk, i visited the p2pu-value-statement-additional, yet to be found?

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!