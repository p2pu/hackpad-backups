# Old Tickets

New suggestions: 

*   [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI)Crowd page - can we make sure words don't get split in the quote (e.g. soc-iety) it is not brelink at soc-iety, but "read only society -(and then it breaks)"
*   [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3)Crowdsourcing expertise - Verhulst pt 2 video - text is too long and needs to be cut 
*   [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3)Big Data - No video for PEntland?
*   [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) Linked Data - No video for Tim Berners Lee? 
*   [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3)Visualization - Deb Roy: text is too long and needs to be cut 
*   @Cosmo Visuzalization - Toolbox - can we have one liners next to the tools mentioned? (THIS APPLIES TO MOST OTHER TOOLBOXES AS WELL) 
*   [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3)Smart disclosure - main video? heading is not complete
*   [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) double check what's going on with the code showing up at the bottom of the page - not sure what are we talking about(Erika)
*   **Updated it, but needs to be double-checked. **Update slider links (unhangout works, the others point to the image files). Can be done in Edit > Post and using the link field in sidebar. 
*   [Claudio Mendonca](https://p2pu.hackpad.com/ep/profile/zeHT9ruLzZn) - Update the topic images with images consistent with the general branding (looks great Claudio) 
*   [Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) - [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) changed the **reply to text for comments**. Need to confirm that it's updating on production. (This ticket can be checked by anyone!) 
*   Nice to have - [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) and All : Make the descriptons un-bolded (PS: Which descriptions?) I think I did most of them already.
*   [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - Under Data and its uses of governance: delete the word "even"; before the word open insert "big, personal and open data"
*   [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI)Titles (data/crowds/Data and its use for governance/Solving public problems with crowdsourcing) should have hyperlinks to thematic pages;
*   [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) The Tim Burners Lee video for Linked Data (it is on toutube youtube) is not showing for some reason. Could you check?  It is actually a TED video. **CANNOT BE RESOLVED**: Only videos on youtube or vimeo will work. Got it. Thank you.
*   Nice to have - On the Theme homepages, can we change the placeholder topic graphics to video thumbnails as on the home page? Choose a thumbnail from any of the videos, taking some case to reflect some diversity in the choices. - Claudo redid this graphics now, they look nicer
*   Nice to have - FOOTER - Add a GovLab logo and hperlink back to www.thegovlab.org do we put any CC BY CA logo there as well? WHAT DO YOU MEAN BY CC BY CA? JUST THE LOGO + LINK TO THEGOVLAB.ORG WOULD BE AWESOME - 
*   [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - Email sign-up. We need at least a thank you confirmation (could be in the modal, or on an empty page). Right now it just dumps people on the Get Involved page, which is confusing. 

Homepage
<ul class="taskdone"><li>Under Behave: swap jen palka's video with thumbnail still of david halpern from this video [](http://www.youtube.com/watch?v=DLKhbTUtSlo)[http://www.youtube.com/watch?v=DLKhbTUtSlo](http://www.youtube.com/watch?v=DLKhbTUtSlo)</li>
<li>for Behave and History: The Coming soons should be under the text </li>
<li>Homepage: History - swap gavin newsom (or whoever the white dude is) with logo from open government partnership [](http://www.opengovpartnership.org/)[http://www.opengovpartnership.org/](http://www.opengovpartnership.org/)</li>
<li>[Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - Under Data and its uses of governance: delete the word "even"; before the word open insert "big, personal and open data"</li>
<li>[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI)Titles (data/crowds/Data and its use for governance/Solving public problems with crowdsourcing) should have hyperlinks to thematic pages;</li>
<li>Cosmo Mission/caption should be: "The GovLab Academy is an online training community that uses technology and innovation to tackle public problems." (delete second sentence) Add: (Version 1.0) the language of the third sentence seem to have changed - Can we keep the old language?</li>
<li>[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) How do I add the hyperlinked to the sign-up page in the second line underneath the main quote? -> **I have added additional field in the dashboard**</li>
<li>The slider seems like it cuts off sentences at the moment - This was due to changing images to be "less taller" it is alright now</li>
<li>Homepage Features: can we replace the about govlab with the crowdsourcing video of Clay Shirky? [Stefaan Verhulst](https://p2pu.hackpad.com/ep/profile/AMb6e1vTdHg) Which video are you referring to specifically? SV: the first one that is at the crowdsourcing opinion and ideas section - </li>
<li>[Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - Homepage - Add short description under the behavioral/history as well + coming soon [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) I am not sure how you've posted the Behavioral Insights and History Blocks. Here is the description of them if uou can help me:<ul class="taskdone"><li>COMING SOON: Learn about research methodology and tech-enabled strategies such as gamification, user-driven design, prizes, and challenges for encouraging large-scale participation.</li>
<li>COMING SOON: Explore the nature of our current crisis of governance, today's international open government movement, and the legal and policy context for innovation in this open governance</li></ul class="taskdone">
</li>
<li>**Content (After OGP) **- Reuse quotes from  [](http://thegovlab.org/what-we-are-inspired-by/)[http://thegovlab.org/what-we-are-inspired-by/](http://thegovlab.org/what-we-are-inspired-by/)  (slider or something)</li>
<li>[Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) Should we have our partnership logos on the about page? MIT Learning, NYU Wagner, Knight Foundation. **PS: Yes. Who has the logos? If you send me the logos I can insert them (or feel free to include them yourself). ** </li>
<li>**Bug** - [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - **Comments don't show up on the Pages** without Sidebar template (see -> [](http://www.thegovlabacademy.org/get-involved/))[http://www.thegovlabacademy.org/get-involved/](http://www.thegovlabacademy.org/get-involved/))</li>
<li>**Design** - [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) (maybe [Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi)) - Clean up default page template (remove posted by and date in heading, <s>remove sidebar DONE)</s></li>
<li>**Bug** - [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - Layout breaks on theme page - [](http://www.thegovlabacademy.org/data/)[http://www.thegovlabacademy.org/data/](http://www.thegovlabacademy.org/data/)</li>
<li>[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - **Add twitter links to avatars** (list of experts). Ideal implementation: hover opens short bio, click takes me to twitter.</li>
<li>**Content** - Add intro video to home page (Question: Also About page?) - Philipp -  I think it would be great to add to the about page, to have them on both. [](http://www.youtube.com/watch?v=NihkaLCtWVo)[http://www.youtube.com/watch?v=NihkaLCtWVo](http://www.youtube.com/watch?v=NihkaLCtWVo) </li>
<li>**Bug - **[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - **Theme Page: Links to topic pages not correct - **All topic images point to [](http://www.thegovlabacademy.org/2013/10/hello-world/)[http://www.thegovlabacademy.org/2013/10/hello-world/](http://www.thegovlabacademy.org/2013/10/hello-world/) (As a workaround I inserted the linke manually into the title)</li>
<li>**Design** - [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - Theme page: Make images full width of the tiles for each Topic area (currently, the image is 40x40 and has a lot of white space around it).</li>
<li>**Design** - [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - Reduce column width for "Readings" and "Toolbox" description text (the text runs too wide - looks funny, hard to read). Can we reduce it to 3/4 or 2/3 of the width and make space for other content on the side? We could add a twitter feed or the images of the people to follow or something else ... </li>
<li>[Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) - **Create Feedback form for channel partners on Get Involved page**</li>
<li>Marilla Li importing expert bios for the remaining pages </li>
<li>[Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) What dimension should the 1) header for the Open Gov Stories and 2) google Form be?  [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) Not sure what you mean ;-) I've updated Open Gov Stories page. Have a look and see if that addresses your question. [Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) When I look at the page in "view" the top image of "open gov stories" does not span all the way across the page. The google forms, however, does. They should be consistent, no? </li>
<li>[Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) - Add Twitter lists to Get Involved page</li>
<li>COsmo getting the images for each topic theme. </li>
<li>[Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) fixing the language for each of the topic descriptions</li>
<li>[Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) - Add form for Open Gov Stories submissions [](https://docs.google.com/forms/d/1tKomF2Pk8CSeWZYaTwVwiIHXipVF8IA-n3PVFX5aTgI/viewform)<u>[https://docs.google.com/forms/d/1tKomF2Pk8CSeWZYaTwVwiIHXipVF8IA-n3PVFX5aTgI/viewform](https://docs.google.com/forms/d/1tKomF2Pk8CSeWZYaTwVwiIHXipVF8IA-n3PVFX5aTgI/viewform)</u><u> </u>@Philipp, I attempted to add it but the width is not reconciled. [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) have a look now. </li>
<li>[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - **Confirm content for theme page - **What should be featured in the four blocks representing the themes? We can include videos or text. SOLUTION: We will use images (Claudio to provide) and short text (Cosmo to provide). Can be added through Theme page editor. </li>
<li>[Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - **GovLab Marquee - **Speak to Claudio about Marquee on TheGovLab site. He will send to us by COB Monday</li>
<li>[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - Add link to Get Involved page to overall navigation</li>
<li>[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - **Topics Page - Add a link to "Further readings" PDF** Add link to "Further reading" on each Topic page (there are only two documents we link to, one for each theme).<ul class="taskdone"><li>Crowdsourcing PDF -> [](http://www.thegovlabacademy.org/wp-content/uploads/2013/10/govlab-academy-readings-crowds-2013Oct.pdf)[http://www.thegovlabacademy.org/wp-content/uploads/2013/10/govlab-academy-readings-crowds-2013Oct.pdf](http://www.thegovlabacademy.org/wp-content/uploads/2013/10/govlab-academy-readings-crowds-2013Oct.pdf)</li>
<li>Data PDF -> [](http://www.thegovlabacademy.org/wp-content/uploads/2013/10/govlab-academy-readings-data-2013Oct.pdf)[http://www.thegovlabacademy.org/wp-content/uploads/2013/10/govlab-academy-readings-data-2013Oct.pdf](http://www.thegovlabacademy.org/wp-content/uploads/2013/10/govlab-academy-readings-data-2013Oct.pdf)</li></ul class="taskdone">
</li>
<li>[Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/uGrwwU8NuhK) - Check **text box limits for Topic pages** (some of the description text overflows)</li>
<li>[Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) **Open Data Topic page** - Tim Berner's Lee video TED (not youtube/vimeo). Need to replace or find youtube/vimeo source. </li>
<li>[Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) - **What is the Ask?** - Email NYU with talking points for conversations at OGP, and copy for Get Involved page (Waiting for feedback from Beth/Cosmo/Stefaan)</li>
<li>**Bug -** [Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) - **Remove sidebar from default pages** (see [](http://www.thegovlabacademy.org/get-involved/))[http://www.thegovlabacademy.org/get-involved/](http://www.thegovlabacademy.org/get-involved/))</li>
<li>[Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/uGrwwU8NuhK) - Add **images to Theme pages** - Note from Philipp: I've addded Claudio's three images to the Data Theme. Please add the others (make sure to reduce their size before uploading. 100x100 is a good size to use for the uploads. <ul class="taskdone"><li>I just sent Philipp and Erika another example -- What do you think? </li></ul class="taskdone">
</li>
<li>**Content **- [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - Theme pages - **Add short descriptions for each topic**. See [](http://www.thegovlabacademy.org/data/)[http://www.thegovlabacademy.org/data/](http://www.thegovlabacademy.org/data/) (the field to insert this information is very small in the editor, but you can use <br> html tags for formatting - see open data example)</li>
<li>Cosmo and All : Make the descriptons un-bolded</li>
<li>[Erika Pogorelc](https://p2pu.hackpad.com/ep/profile/oTNkHa0lFrI) add description of the govlab on the lower section of the homepage where it says "featured content" 

*   The GovLab Academy is a free online community for those wanting to teach and learn how to solve public problems and improve lives using innovations in governance. A partnership between the GovLab and MIT Media Lab’s Online Learning Initiative, the site launching today offers curated videos, podcasts, readings and activities designed to enable the purpose driven learner to deepen his or her practical knowledge at her own pace.    
</ul class="taskdone">

*   @Marilla Li Change the thumbnail for the Crowdsourcing video (Beth's image) 

**Non Web Site Tickets**

*   [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - Sign us up for **Tech Camp** (with Stefaan) on Sat
*   [Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi) - **1 pager** announcement (for print)
*   [Philipp Schmidt](https://p2pu.hackpad.com/ep/profile/Dc7zU8svumi)/ [Cosmo Fujiyama](https://p2pu.hackpad.com/ep/profile/FvW0oXx7eF3) - Prepare **Launch Blog post **on TheGovLab.org about The Academy (to show up on homepage) (Joel is woking on one for us) 