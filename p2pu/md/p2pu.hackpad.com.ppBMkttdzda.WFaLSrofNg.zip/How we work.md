# How we work

**We are a community **

We're a group of learners, coders, thinkers, practitioners, educators and organizers. We come together on our Discourse community to share resources, recommendations and support each other to build learning communities. 

*   should we include makers or coders in there? 
*   "Practioners?" 
*   I'm actually not 100% sure what practitioners mean? Who would qualify? 
*   people who make and do the thing

(link to community.p2pu.org)

**We build learning communities online**

We craft great online learning experiences using the best tools for the job. 

(link to section with courses)

**We make how-to's and toolkits **

We document how we make engaging, innovative, sustainable learning experiences, and we create tools to help you make your own.

(link to blog and reports)

**We answer the hard questions**

We have a regular round table where we discuss big questions in open online learning, share our successes and learn from each other. Guests include folks from Khan Academy, Hack Education, Mozilla and NYU. 

(link to round tables)

**We give talks and workshops**

We go to conferences to share our expertise on learning technology, community design and openness. 

(link to talks)

**We help folks make open courses and tools**

If you're looking to make a course, get started with our "School in a Box." We also provide consulting services in learning design, technical implementation and community-building. 

(link to social learning course)

*   link to contact us as well?

-----

**Section for courses**

A tile for showcase courses we are working on and other high quality courses.

*   Top notch learns

(link to lernanta course listing)