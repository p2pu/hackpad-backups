# Community Call 6 February 2014

We're hanging out here: [](https://plus.google.com/hangouts/_/hoaevent/AP36tYe9wdqnIdr6gmib9MTLJ1P6KKcQS6dEDfanotMNlljCYDvsNQ?authuser=1&hl=en)https://plus.google.com/hangouts/_/hoaevent/AP36tYe9wdqnIdr6gmib9MTLJ1P6KKcQS6dEDfanotMNlljCYDvsNQ?authuser=1&hl=en

 - join us! 

**Attendees**

*   Bekka Kahn
*   [Erika Pogorelc](/ep/profile/oTNkHa0lFrI) 
*   [Philipp Schmidt](/ep/profile/Dc7zU8svumi)
*   [Carl Ruppin](/ep/profile/mNzH4UoHZhs)
*   [Dirk Uys](/ep/profile/ppBMkttdzda)
*   [Vanessa Gennarelli](/ep/profile/ufOl3tEe6YY)

*   New format: an experiment ? ** the experiment is over! **

**The P2PU Weekly **

*   What's keeping our minds occupied (10 min) - WIP board: [](https://trello.com/b/8NlzI2nG/wip)[https://trello.com/b/8NlzI2nG/wip](https://trello.com/b/8NlzI2nG/wip)
*   UPDATE: New format for this call: P2PU now doing a 'project call' at 10am EST Thursdays (1hr before this call) to report on work in progress and discuss specific projects.

*   BK: Promotion and co-ordination for 3 posts (WikiSoO, DLMOOC & Assessment Report)
*   ED Search admin
*   Google ad words - like metadata for money

**Agenda for discussion**

Different calls / When & what :

*   New format for this call: P2PU now doing a 'project call' at 10am EST Thursdays (1hr before this call) to report on work in progress and discuss specific projects.
*   3 calls:

        *   project call - Thurs 10-11 EST - for all-hands, discuss work in progress, focussed on update and feedback from full team
    *   community call - Thurs 11-12 EST - for all-hands but more 'meta' discussions - process, bigger issues, discussion topics? <u>full team</u>
    *   personal office hours - 6 1hr timeslots through the week - for discussing/working on your particular projects 

*   Implications for old calls/meetings:

        *   old community call and tech call are replaced by new project call and community call
    *   old 1-on-1 meetings won't continue (replaced by personal office hours)
    *   old all-hands office hours (Mon 10-12 EST) stays on for now

*   All calls have been added to the P2PU Events calendar

How are personal office hours going? Lessons learned? Strategies to share? 

*   Does everyone keep the office hours blocked in the calendar, or do they get "scheduled"?

Community Members on thepeople:

*   Dave's comments on unhangouts [](http://thepeople.p2pu.org/t/one-dudes-feeling-about-unhangouts/405)http://thepeople.p2pu.org/t/one-dudes-feeling-about-unhangouts/405

New Projects

*   GovLab, Music MOOC and DLMOOC are wrapping up, 
*   New projects for 2014: 
*   School of Webcraft (end April launch) Internet of Things (quarters 2 & 3)
*   What does the rest of the year look like? (wider discussion)

ED Search (pre-update)

*   Currently finalizing announcements, evaluation criteria etc.
*   Announce it (next week?)
*   Team to be involved in all aspects

Blog slow? (lets discuss this separately DU)

*   Discussion about Dreamhost is in order (we might "trash" it )

Tips & Tricks for using Trello

*   Filter cards by people who are "members" of the card (you can do this in the right hand column)
*