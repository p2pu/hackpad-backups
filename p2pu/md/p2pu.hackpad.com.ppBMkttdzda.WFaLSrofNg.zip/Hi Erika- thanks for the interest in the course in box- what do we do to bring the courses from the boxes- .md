# Hi Erika, thanks for the interest in the course in box, what do we do to bring the courses from the boxes? 

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!