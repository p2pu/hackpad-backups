# Community Call - 31 October 2013

We're hanging out here: [](https://plus.google.com/hangouts/_/76cpjv4tcrcjvu6olohdfkkon4?authuser=1&hl=en)https://plus.google.com/hangouts/_/76cpjv4tcrcjvu6olohdfkkon4?authuser=1&hl=en

**Projects**

**Progress**

*   Music MOOC

        *   Content review: videos, emails
    *   G+ Community Management
    *   Social Media Management
    *   Grouping 

                *   [](http://jsfiddle.net/dirkcuys/TUq5a/7/)http://jsfiddle.net/dirkcuys/TUq5a/7/

        *   Class photo

*   Data Explorer Mission

        *   Recap/write up complete--need to post [Bekka Kahn](/ep/profile/BT4g65BvPRV) :)
    *   [](https://docs.google.com/document/d/1VviIB6__Zu6x3V19JCtcJTC-x8t1UEFi9HopQNfYuI8/edit?usp=sharing)https://docs.google.com/document/d/1VviIB6__Zu6x3V19JCtcJTC-x8t1UEFi9HopQNfYuI8/edit?usp=sharing

**Priorities**

[](https://twitter.com/p2pu/status/395915405602340865)https://twitter.com/p2pu/status/395915405602340865

**Problems**

**Process**

Agenda for discussion:

Music MOOC

*   Signup Status

        *   4,903 signups
    *   27,765 pageviews
    *   Main sources of traffic: lifehacker, facebook, twitter

*

[](http://cl.ly/SF6x)http://cl.ly/SF6x

[](http://cl.ly/SF2q)http://cl.ly/SF2q

*

[](http://cl.ly/SDP4)http://cl.ly/SDP4

*

[](http://cl.ly/SFIG)http://cl.ly/SFIG

Community Management/Learning Lead Roles

Community Call revamp

PR Strategy:

*   Longer-form blog posts
*   Reaching outside the ed world
*   Nurturing relationships with bloggers and reporters in wider culture (awl, fastcompany, wired, boingboing)