# Community Call 22 May 2014

Event link: [](https://plus.google.com/events/cvato7o5shrgg5r4cjsskftepm0)https://plus.google.com/events/cvato7o5shrgg5r4cjsskftepm0

Attendees:

*   [Dirk Uys](/ep/profile/ppBMkttdzda) 
*   [Erika Pogorelc](/ep/profile/oTNkHa0lFrI) 
*

Agenda:

*