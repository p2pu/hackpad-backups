# You're all Signed Up for [#inventanything](/ep/search/search?q=%23inventanything)!

We're so glad you are here.  A few details to get you sorted:

*   **We'll start on February 23rd. **You will get an email from us with your weekly Design Challenge and directions for the Community Call.
*   **While you are waiting, you can listen to some hold music **[](https://www.youtube.com/watch?v=tmaJDHKOEiM)**https://www.youtube.com/watch?v=tmaJDHKOEiM**

**or sign up** for our community site and come introduce yourself to our forums, we are a friendly bunch!

*   link 1 [](http://littlebits.cc/projects)http://littlebits.cc/projects
*   link 2 [](http://discuss.littlebits.cc/)http://discuss.littlebits.cc/
*   **Invite a friend to make with you! **It's better together :)
*   **Tell us what you are excited to learn using the hashtag **#I[n](/ep/search/?q=%23I&via=ZDBoKfSpFQV)[v](/ep/search/?q=%23In&via=ZDBoKfSpFQV)[e](/ep/search/?q=%23Inv&via=ZDBoKfSpFQV)[n](/ep/search/?q=%23Inve&via=ZDBoKfSpFQV)[t](/ep/search/?q=%23Inven&via=ZDBoKfSpFQV)[A](/ep/search/?q=%23Invent&via=ZDBoKfSpFQV)[n](/ep/search/?q=%23InventA&via=ZDBoKfSpFQV)[y](/ep/search/?q=%23InventAn&via=ZDBoKfSpFQV)[t](/ep/search/?q=%23InventAny&via=ZDBoKfSpFQV)[h](/ep/search/?q=%23InventAnyt&via=ZDBoKfSpFQV)[i](/ep/search/?q=%23InventAnyth&via=ZDBoKfSpFQV)[n](/ep/search/?q=%23InventAnythi&via=ZDBoKfSpFQV)[g](/ep/search/?q=%23InventAnythin&via=ZDBoKfSpFQV)[  on twitter ](/ep/search/?q=%23InventAnything&via=ZDBoKfSpFQV)
*   Learn more about what to expect from the course at littlebits.cc/hello-inventanything

([About InventAnything ^)](/US9NMH1Bc63)

A warm littleBits welcome, 

Chloe and [Vanessa](/ep/profile/ufOl3tEe6YY) 