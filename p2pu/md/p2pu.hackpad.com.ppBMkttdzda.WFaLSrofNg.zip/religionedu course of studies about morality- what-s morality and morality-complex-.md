# religionedu course of studies about morality, what's morality and morality-complex:

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!