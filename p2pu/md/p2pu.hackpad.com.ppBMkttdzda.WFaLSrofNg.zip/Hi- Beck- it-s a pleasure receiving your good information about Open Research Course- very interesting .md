# Hi, Beck, it's a pleasure receiving your good information about Open Research Course, very interesting 

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!