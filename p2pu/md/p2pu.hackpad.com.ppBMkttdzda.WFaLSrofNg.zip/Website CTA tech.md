# Website CTA tech

How do we integrate with p2pu.org?

*   Embed 3rd party tool (like MailChimp)
*   JS <--
*   Custom App

How do we develop/design form?

*   3rd party tool -> MailChimp, typeform
*   HTML5 + JS

Where do we store data

*   3rd party tool
*   custom tool -> maybe p2pu SSO-ish thing

How do we automate?

*   IFTTT
*   Other 3rd party tool - Zapier

How do we track goals

*   GA
*   custom dash