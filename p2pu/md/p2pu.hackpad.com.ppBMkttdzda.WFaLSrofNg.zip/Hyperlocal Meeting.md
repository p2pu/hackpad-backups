# Hyperlocal Meeting

#Science Everywhere

How do we learn w kids

Bridge learning from school to church to home

Talking through these issues with the neighborhood

Perspectives from different people--community stakeholders

Build a course for the general public for these issues--get feedback

How Should Parents Manage Technology With Their Children?

Cooney Center

Kinds tape perspectives

**Themes**

*   Knowing how to learn together is actually really difficult

        *   kids and parents have different ideas about how to learn together
    *   parents are very concerned with formal definitions of learning (helping kids w homework)
    *   students "oh I learned this cool thing with my mom the other day"-->bridging that gap

*   Managing technology with your kids 

        *   responsible uses of technology with kids
    *   parents and kids together

*   Promoting learning within schedules
*   Recognizing learning in less formal and less traditional structures
*   Managing frustration
*   Helping parents find resources to help

** Vanessa Questions**

*   Surprises you from meetings
*   Themes that are coming up
*   Live events
*   Help for tomorrow
*   recruitment-->wide diversity of parents
*   what would it look like and instructional design

** Sample P2PU Experiences**

*   [](https://training.webmakerprototypes.org/en/)https://training.webmakerprototypes.org/en/
*   [](http://learn.media.mit.edu/lcl/)http://learn.media.mit.edu/lcl/
*   [](http://www.playwithyourmusic.org/)http://www.playwithyourmusic.org/
*   [](https://unhangout.media.mit.edu/event/edcamp-online)https://unhangout.media.mit.edu/event/edcamp-online
*   [](http://howto.p2pu.org/modules/content/concepts/)http://howto.p2pu.org/modules/content/concepts/

** Our Design Process**

*    Take themes-->render them into learning goals
*   Design collaborative exercises around those learning goals
*   Find 10 folks to co-design with us-->vet the projects
*   Cull and curate resources
*   Invite folks to break the site

Go through your videos and design something to do with your parents

design a way to learn with your parents