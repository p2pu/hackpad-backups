# [](https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXA)https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXA

[](https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXAdhrTCmDhfPQ9NUr5SA)https://plus.google.com/hangouts/_/hoaevent/AP36tYdzArb0r6XHbWoN_kPHOPKOe9LJrYXAdhrTCmDhfPQ9NUr5SA 