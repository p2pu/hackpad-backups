# It's believed that some addition or amendment input is rated to write for change

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!