# 2014 02 06 - Project Call

What are Project Calls for?

*   Weekly all-hands call for P2PU 360
*   With enough time to ask questions and have interesting discussions
*   Use Trello WIP board to guide discussion - [](https://trello.com/b/8NlzI2nG/wip)https://trello.com/b/8NlzI2nG/wip
*   Accountability to the team
*   Details get moved into personal office hours
*   Calls are recorded On Air and shared
*   Open to anyone

**General Project Updates -> This call**

**Topics that are relevant to ALL team -> Community call**

**Topics that require only parts of the team -> Personal office hours**

Make sure topics are discussed in the right call

[](https://trello.com/b/8NlzI2nG/wip)https://trello.com/b/8NlzI2nG/wip

*   Jekyll course template (DU)

        *   PS: use it ourselves before spreading the word
    *   PS: prefer forking over other methods
    *   DU todo: check if Github now supports forking a project more than once

*   DLMOOC (DU)

        *   some support wrt users who signed up for pilot but not real course (+- 40)
    *   investigating chat options

*   GovLab academy project done and dusted (EP)
*   School of Open - Wordpress for landing page (EP)

        *   mockup progressing nicely

*   Badges embedding question by (VMG)

        *   EP working on fix for badges problem

*   P2PU course on online learning (VMG)

        *   discussion on discourse

*   PWYM (VMG)

        *   Crunching data and writing report
    *   conversation around looking at the groups that did work and figuring out why?

*   Assessment report (VMG)

        *   1st one out the door
    *   working on 2nd one

*   Badge summit (VMG)

        *   going to San Francisco next week

*   LCL 2 (PS)

        *   Planning + infrastructure
    *   Considering Github Pages and Discourse

*   Video for the German year of Science (PS)
*   ED search and other stuff (PS)
*   Change of address (PS)