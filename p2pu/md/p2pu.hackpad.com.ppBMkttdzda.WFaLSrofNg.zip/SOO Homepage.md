# SOO Homepage

Please put in your feedback here:

**General**:

Carl: what's the plan re discussion forum?  Is there any chance they would integrate their forum with ours (eg SoO becomes topics/subdomains on our disqus)?  One way to (a) build overall P2PU community, and (b) keep involvement/commonality with our showcases (that we otherwise hand off to others) might be a shared forum community? Thoughts?? 

**Green**: overall - it's lovely. Nice one.  (CR: +1) 

 It looks really nice and a huge improvement over the current school landing page

**Yellow:**  As a visitor, I'd like to see an About page pretty high on the list, so I could work out what's going on?  There's an about link for P2PU but don't see one for the school.  Tho Jane's call I guess.

**Yellow**: I'm not sure about the petal shaped textboxes for "workshops" only because the look is quite blocky up to that point. But this is minor. 

Last yellow: our logo should be as big as the CC one in the masthead.   Also, I wonder if the logos could sit side-by-side, so it has more of that joint-effort appearance - a P2PU:CC production...

**Yellow:** Colour scheme is not the best (Philipp)

**Red:**