# Pittsburg

## Display LCs for specific course on Ciab page

*   JSON / JSONP (learningcircles.p2pu.org) + JQuery (CiaB)

        *   <script type="text/JavaScript">function loadCircles(circleArray){ };</script>
    *   <script src="[](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadCircles)https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=[l](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=)[o](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=l)[a](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=lo)[d](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loa)[C](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=load)[i](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadC)[r](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadCi)[c](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadCir)[l](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadCirc)[e](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadCircl)[s](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadCircle)[" >](https://learningcircles.p2pu.org/en/learningcircles/?course_id=99&callback=loadCircles)

*   JavaScript (learningcircles.p2pu.org)

**API on learningcircles.p2pu.org**

**Display on GithubPage**

*   JQuery for rendering components

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!