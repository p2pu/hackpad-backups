# Learning family learing

[](http://www.learningfamilylearning.org/)http://www.learningfamilylearning.org/

When do signup open?

*   after site is complete (with all content) (Aim for March 1st)

When do course start?

*   decide date after that (maybe twee weeks) (Aim for March 16th)

Forum: discourse.p2pu.org

Sending emails to signups and tracking number: 

June: way to style 1 article per module, to be placed in the readings

Will be 5 articles total, need to fit in frame

Module feedback

Marketing

*   Vanessa wants a about 1 pager to Vanessify
*   Educon - people went crazy! Want a place to learn more about learning family learning. Want to put on Educon newsletter.

Other misc:

[](https://fallingdust.com/N103/)https://fallingdust.com/N103/

Vanessa coming to visit [June Ahn](/ep/profile/vBXudnijo9s)

*

Todo

*   DU: Add topnav link to articles and have page where articles are listed
*   DU: Send instructions to June about adding articles
*   DU: Project gallery - Grab projects from special category
*   VMG to schedule discourse demo with team awesome
*   VMG feedback on values: discourse prompts, kinds of activities we've found successful
*   Team awesome: content week this week
*   VMG + team awesome: meet next week wednesday 3 (:15ish) EST

        *   agenda: discourse, event/meetup guides (VMG to chew)

*   DU: schedule with June to demo Mech MOOC for sending out emails
*   DU: send June link to signup success page
*   JA: About page (1 pager)
*   VMG: Circulate 1 pager to Educon newsletter (March 1st)
*   DU: Topnav: About single page & module called start here in place of FAQ
*   DU: Create trello tickets from this meeting