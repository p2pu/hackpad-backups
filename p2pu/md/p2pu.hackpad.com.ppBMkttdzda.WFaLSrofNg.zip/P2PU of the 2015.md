# P2PU of the 2015

CR: Have a **concrete** offering of what P2PU is about and what we are offering

Focus on "Course in a Box"

VMG: help people setup Discourse

Find ways to market test what we offer and see if there is demand. "Do you need help building learning communities on the web?"

Measuring community heartbeat and growth/strength.

BK: We need to be flexible about what we want to do

We should know what we need to deliver on because we have funding and what we want to do

Implement marketing plan that we develop with Elliott - how we speak about P2PU

Build more relationships with other organizations

PS: feeling good about things moving forward

Reflect on where we are, we are in a good space, we have a year or two to chase them

Excited about consulting. OpenIdeo - they build platforms for big partners

We need to think about $100k - 200k consulting

Research - we should still do crazy stuff

We need to get better at things

We don't have a set of cool tools right now.

Unhangouts - investigate possibility of P2PU being a 'service provider'

How do we start/sustain/handover communities. Community life-cycle. Maybe offer community managers.

Help most with new opportunities and tools (product side)

EP: wants to build stuff (not just for the sake of building)

MORE metrics. Not the creepy kind, but data to make sure we are building what people want

Want to get bigger - spread out of North America - maybe Europe

DU: Building out the tools and communicate better about it

Develop how we help wrt to consulting

Figure out what it means to be a P2PU community (inspired by the way Couch Surfing communities in different places are all very cool, but very different as well.

BK: Sharing and communicating more about how we do stuff.