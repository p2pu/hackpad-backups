# Call with beatrice M. 

ethics and responsible data. a movement starting from ppl working in digital community over last 12 mths or so, 1st expression was Feb 2014 - Responsible Data Forum - started by The Engine Group together with Gunner/Aspiration Tech. Brainstorm/pilot around rights org in CA last year; now see eg responsbiledata.io. Connecting with funding from Knight Foundation and others.

[check about/people pages there for others active at the moment]

The data community has been managed by a fairly niche community so far, more at government, academic level. Now some friction arising as citizen scientists start to have growing awareness - both of opportunities but also threats - surveillance, etc. Citizen scientists in government, in media, in marketing and social media side. Start-ups and tech people getting concerned - why are we collecting so much data, what are we doing with it. 

Current gaps:

*   Movement now recognises need for responsible data use / ethics in data
*   Citizen and mainstream media are interested in ethical use of data
*   Audience: 

Marketing / start-up side interested too:

Startups are collecting a lot of data, beginning to question why they're collecting it, what to do with it, and how to manage it, and being accountable to their users with regards to their data

opportunity - the topic of data is no longer for the academic communities, and more more people are starting to get interested in it. 

responsible data forum [](https://responsibledata.io/)https://responsibledata.io/

*   Coalition of various orgs (knight, tactical tech, aspiration etc )  organise events, thinking about how to make connections between the world and those people / orgs who are involved in these conversations

Data 1.0 is basic skills

Data 2.0 is the ethical stuff around data, 

What are the givens: 

*   Do people know what open data is? 
*   Do people know what openness in the data space might be? 
*   Are they data literate?

**Possible partners: **

DataKind: [](http://www.datakind.org/)http://www.datakind.org/

**Data vs Statistics**

There are potential designs around statistics which are potentially compelling, and popular, might be less "meta" than the data, and we're trying to move away from the meta stuff and into the bread and butter stuff. 

Start with the hard skills first, meta maybe later - 