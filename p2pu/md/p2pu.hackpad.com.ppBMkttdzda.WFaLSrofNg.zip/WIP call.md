# WIP call

Re-jigging WIP call?

Would be good to have timesheet discussion - helps show what might be needed

Concerns:

  - too much time on meetings?

  - lack of focus on deliverables/pipeline?

  - having trouble prioritising what <u>needs</u> to get done

  - not having Grif on our 2 all-hands meetings - would like him to be on them

  - noting we have 'talk' meetings and 'doing' meetings - something like Knight project call is work not ''meeting''  -> meaning we have only 2 hrs of meetings

  - do we need an hour on these meetings? 

*     - VMG: what is WIP meeting meant to achieve (exec function vs operational/oversight function) - should it just be 15min? Project manager to get project deliverables 

**  So what should this meeting achieve:**

  - transparency into deliverables and deadlies

  - update on progress against those deadlines / problems/ changes needed

  - avoid fragmentation into small silos doing their own thing

**  Proposals:**

  - split call into half what I did this week half what I'll do next week?

  - need to re-visit pipeline;

  - identify project manager for every project; make them 

  - maybe keep existing cards; each project manager talk to where the project is at, what's been done, what's next

This pad text is synchronized as you type, so that everyone viewing this page sees the same text.  This allows you to collaborate seamlessly on documents!