# P2PU Auth

**Shopping list**

*   OAuth2 provider
*   Discourse SSO ([](https://meta.discourse.org/t/official-single-sign-on-for-discourse/13045))https://meta.discourse.org/t/official-single-sign-on-for-discourse/13045)
*   Wordpress SSO
*   Badges SSO (OAuth2)
*   Set *.p2pu cookie for automatic SSO on sites that supports it
*   DNS: login.p2pu.org or auth.p2pu.org
*   Method for SSO from non *.p2pu.org domains